//*****************************************************************************
// Copyright (C) 2014 Texas Instruments Incorporated
//
// All rights reserved. Property of Texas Instruments Incorporated.
// Restricted rights to use, duplicate or disclose this code are
// granted through contract.
// The program may not be used without the written permission of
// Texas Instruments Incorporated or against the terms and conditions
// stipulated in the agreement under which this program has been supplied,
// and under no circumstances can it be used with non-TI connectivity device.
//
//*****************************************************************************

#include <string.h>
#include <stdlib.h>

unsigned char atoc(char data);
unsigned char atod(char data);
long atolong(char *data, unsigned long *retLong);
unsigned char ascii_to_char(char b1, char b2);
unsigned short itoa(short cNum, char *cString);
const char     pcDigits[] = "0123456789"; /* variable used by itoa function */

//*****************************************************************************
//
//! atoc
//!
//! @param  none
//!
//! @return hexadecimal equivalent
//!
//! @brief  Convert nibble to hexdecimal from ASCII
//
//*****************************************************************************
unsigned char atoc(char data)
{
    unsigned char ucRes;

    if ((data >= 0x30) && (data <= 0x39))
    {
        ucRes = data - 0x30;
    }
    else
    {
        if (data == 'a')
        {
            ucRes = 0x0a;;
        }
        else if (data == 'b')
        {
            ucRes = 0x0b;
        }
        else if (data == 'c')
        {
            ucRes = 0x0c;
        }
        else if (data == 'd')
        {
            ucRes = 0x0d;
        }
        else if (data == 'e')
        {
            ucRes = 0x0e;
        }
        else if (data == 'f')
        {
            ucRes = 0x0f;
        }
    }


    return ucRes;
}

//*****************************************************************************
//
//! atod
//!
//! \param  none
//!
//! \return Decimal value of ASCII char
//!
//! \brief  Convert ASCII char to decimal
//
//*****************************************************************************
unsigned char atod(char data)
{
    unsigned char retVal = 0xff;

    if ((data >= 0x30) && (data <= 0x39))
    {
        retVal = data - 0x30;
    }

    return retVal;
}

//*****************************************************************************
//
//! atolong
//!
//! \param  none
//!
//! \return Return long value else -1 as error
//!
//! \brief  Convert ASCII string to long
//
//*****************************************************************************
long atolong(char *data, unsigned long *retLong)
{
    unsigned char cycleCount = 0;
    unsigned char digit;

    if((data == NULL) || (retLong == NULL))
    {
        return (-1);
    }

    *retLong = 0;
    while ((digit = atod(*data)) != 0xff)
    {
        *retLong *= 10;
        *retLong += digit;
        data++;
        cycleCount++;
    }

    return cycleCount;
}

//*****************************************************************************
//
//! ascii_to_char
//!
//! @param  b1 first byte
//! @param  b2 second byte
//!
//! @return The converted character
//!
//! @brief  Convert 2 bytes in ASCII into one character
//
//*****************************************************************************

unsigned char ascii_to_char(char b1, char b2)
{
    unsigned char ucRes;

    ucRes = (atoc(b1)) << 4 | (atoc(b2));

    return ucRes;
}

//*****************************************************************************
//
//! htoa
//!
//! @param  none
//!
//! @return status
//!
//! @brief  Converts hexa string to ascii
//
//*****************************************************************************
int htoa(char* Buf)
{
    int i, len;
    char Byte[8];

    len = strlen(Buf);

    //check data validity
    for (i = 0; i < len; i++)
    {
        if(((Buf[i] >= 0x30) && (Buf[i] <= 0x39)) || \
        ((Buf[i] >= 0x41) && (Buf[i] <= 0x46)) || \
        ((Buf[i] >= 0x61) && (Buf[i] <= 0x66)))
        {
            continue;
        }
        else
        {
            return -1;
        }
    }

    for (i = 0; i < (len / 2); i++)
    {
        strncpy(Byte, &Buf[i * 2], 2);
        Buf[i] = strtol(Byte, NULL, 16);
    }

    return 0;
}

//*****************************************************************************
//
//! btoa
//!
//! @param  none
//!
//! @return status
//!
//! @brief  Converts binary string to ascii
//
//*****************************************************************************
int btoa(char* Buf)
{
    int i, len;
    char Byte[8];

    len = strlen(Buf);

    //check data validity
    for (i = 0; i < len; i++)
    {
        if ((Buf[i] != 0x30) && (Buf[i] != 0x31))
        {
            return -1;
        }
    }

    for (i = 0; i < (len / 8); i++)
    {
        strncpy(Byte, &Buf[i * 8], 8);
        Buf[i] = strtol(Byte, NULL, 2);
    }

    return 0;
}
//*****************************************************************************
//
//! itoa
//!
//!    @brief  Convert integer to ASCII in decimal base
//!
//!     @param  cNum is input integer number to convert
//!     @param  cString is output string
//!
//!     @return number of ASCII parameters
//!
//!
//
//*****************************************************************************
unsigned short itoa(short cNum, char *cString)
{
    char* ptr;
    short uTemp = cNum;
    unsigned short length;

    // value 0 is a special case
    if (cNum == 0)
    {
        length = 1;
        *cString = '0';

        return length;
    }

    // Find out the length of the number, in decimal base
    length = 0;
    while (uTemp > 0)
    {
        uTemp /= 10;
        length++;
    }

    // Do the actual formatting, right to left
    uTemp = cNum;
    ptr = cString + length;
    while (uTemp > 0)
    {
        --ptr;
        *ptr = pcDigits[uTemp % 10];
        uTemp /= 10;
    }

    return length;
}


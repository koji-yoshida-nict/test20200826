/*
 * combuf_man.h
 *
 *  Created on: 2016/06/24
 *      Author: ohuchi
 *      Update: tmiki
 */


//#include <FreeRTOS.h>
//#include <queue.h>
//#include <portmacro.h>

#ifndef SRC_COMMON_COMBUF_MAN_H_
#define SRC_COMMON_COMBUF_MAN_H_

// =========================================================
//
#include "application/app_version.h"
#include "tp_stddef.h"

// ====================================================
// FIFO class
// ====================================================
#include "container_def.h"

#ifdef USE_FREERTOS
// =========================================================



#else

#define portMAX_DELAY 0
typedef int TickType_t ;
typedef int BaseType_t ;

#endif
// =========================================================

#define	CMBFHF_ALLOC	1
#define	CMBFHF_FREE		2

#define	COMBUF_INFOMAX  (16)
#define	COBUFLEN        (1024)
#define CMB_MAX_DELAY   portMAX_DELAY

/////////////////////////////////////
//	HOOK関数について
/////////////////////////////////////

// =========================================================
#if 0
#ifdef VER1_0_0

#else
typedef	struct	tagCOMBUF_HED {
	uint8_t	cominfo_handle;
	uint8_t	lock;
	uint8_t	buf[0];
} COMBUF_HED  ;
typedef struct tagCOMBUF_HED *COMBUFP;
typedef int8_t COMBUFHANDLE;
#endif
#endif
//
#define	COMBUFHED_SIZ (sizeof(COMBUF_HED))
#define	COMBUF_CARRYP(p) (&((COMBUFP)(p))->buf)
#define	CARRYP2COMBUF(c) (void*)((unsigned)(c) - COMBUFHED_SIZ)
#define	COMBUFPSIZ (sizeof(COMBUFP))

// =========================================================
// creater
COMBUFHANDLE combuf_create(uint16_t buffSize ,uint8_t MaxRow);
int8_t  combuf_clear(COMBUFHANDLE handle);

// =========================================================
// allocet buffer
extern  COMBUFP combuf_alloc(COMBUFHANDLE handle, TickType_t ptt);
extern  COMBUFP	combuf_alloc_FromIsr(COMBUFHANDLE handle);

// =========================================================
// free buffer
extern  int combuf_free(COMBUFP	bufp, TickType_t ptt);
extern  int	combuf_free_FromIsr(COMBUFP	bufp );

// =========================================================
// user I/F

#define	combuf_alloc_block(h)	combuf_alloc(h, CMB_MAX_DELAY)
#define	combuf_alloc_nonb(h)	combuf_alloc(h, 0)
#define	combuf_alloc_isr(h)		combuf_alloc_FromIsr(h)

#define	combuf_free_block(b)	combuf_free((b), CMB_MAX_DELAY)
#define	combuf_free_nonb(b)	    combuf_free((b), 0)
#define	combuf_free_isr(b)		combuf_free_FromIsr((b))

#endif /* SRC_COMMON_COMBUF_MAN_H_ */

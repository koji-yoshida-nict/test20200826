/*
 * combuf_man.c
 *
 *  Created on: 2016/06/24
 *      Author: ohuchi
 */
// =========================================================
// free_rtos/ti-rtos includes

#ifdef USE_FREERTOS
#include "FreeRTOS.h"
#include "portmacro.h"
#include "queue.h"

#else

// =========================================================
// tirtos
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Queue.h>

#define pdTRUE 1
#define pdFALSE 0
#define portBASE_TYPE long
//#define NULL 0L

#endif

#include "container_def.h"
#include "combuf_man.h"
#include "esymalloc.h"

// =========================================================
//
#ifndef USE_FREERTOS
// =========================================================

portBASE_TYPE Queue_send(QueueHandle_t a1,void * a2, portBASE_TYPE a3)
{
    Queue_put(a1,a2);
//    Queue_enqueue(a1,a2);
    return pdTRUE ;
}

portBASE_TYPE Queue_sendIRS(QueueHandle_t a1,void * a2, portBASE_TYPE a3)
{
    Queue_put(a1,a2);
//    Queue_enqueue(a1,a2);
    return pdTRUE ;
}

void *Queue_receive(COMBUFHANDLE a1, void * a2, portBASE_TYPE a3)
{
    while( CMB_MAX_DELAY == a3){
        if( !Queue_empty(a1) )
            break ;
    }
    return Queue_get(a1);
//    return Queue_dequeue(a1);
}

#endif

// =========================================================
//
typedef	struct	tagCOMBUF_INFO	{
	uint8_t	*base;				 // メモリ空間ベース
	uint8_t	recsz;				 // レコードサイズ。
	uint8_t	recnum;				 // レコードカウンタ
	QueueHandle_t que_alloc;	 // アロケート用パイプ
	void (*hookfunc)(int8_t,void*); // メモリ取得解放のフック関数
	void *hf_param;		         //	フック関数への引数
} COMBUF_INFO;

static COMBUF_INFO infotbl[COMBUF_INFOMAX];
static int8_t combufinfo_tbl_use = -1;	// 初めは0にもならない。

// =========================================================
// combuf管理領域を作成する。
// 作成できなかった場合には、0以下の数値を返す。
//
COMBUFHANDLE combuf_create(uint16_t	recsiz,uint8_t recno )
{
	uint8_t	*allocp;
	uint16_t size;
	QueueHandle_t que_allc;
	uint8_t	comtblcnt;
	COMBUF_INFO	*info;

	// =========================================================
	//	管理領域の残りを確認
	if ((comtblcnt = combufinfo_tbl_use+1) >= COMBUF_INFOMAX)
		return ERR;	         //	領域がない。
	// =========================================================
	// パイプ領域を取得

    if (!(que_allc = Queue_create(recno, COMBUFPSIZ )))
//	if (!(que_allc = xQueueCreate(recno, COMBUFPSIZ )))
		return ERR;	         //	領域がない。
    size = (recsiz += sizeof(ContainerObj));
//	size = (recsiz += sizeof(COMBUF_HED));
	size *= recno;

	// =========================================================
	// 実バッファ領域を取得
	if (!(allocp = _MALLOC(size)))
		return	ERR;

	combufinfo_tbl_use = comtblcnt;
	info = &infotbl[comtblcnt];
	info->base	    = allocp;
	info->recsz	    = recsiz;
	info->recnum	= recno;
	info->que_alloc	= que_allc;
	info->hookfunc	= 0;
	info->hf_param	= 0;

	return	comtblcnt;
}

#define	HANDLE_CHECK(hn) ((0 <= (hn)) && ((hn) <= combufinfo_tbl_use))

/// =========================================================
// 共有メモリの領域を初期化する。
//
int8_t combuf_clear(COMBUFHANDLE comtblcnt)
{
	int	i;
	uint8_t* bufp;
	COMBUF_INFO	*info;

	if (!(HANDLE_CHECK(comtblcnt)))
		return	ERR;
	info = &infotbl[comtblcnt];
	// =========================================================
	// キューの内部を初期化する。
	for (i = 0, bufp = info->base; i < info->recnum; i++) {
		((COMBUFP)bufp)->cominfo_handle = comtblcnt;
		((COMBUFP)bufp)->lock			= 0;
		if(Queue_send(info->que_alloc, (void *)&bufp, portMAX_DELAY) != pdTRUE)
//        if (xQueueSend(info->que_alloc, (void *)&bufp, portMAX_DELAY) != pdTRUE)
			break;
		bufp += info->recsz;
	}
	if (i != info->recnum)
		return	ERR;

	return	SUCCESS;
}

// =========================================================
// 決められたメモリサイズでメモリブロックを取得します。
//
COMBUFP	combuf_alloc(COMBUFHANDLE handle, TickType_t ptt)
{
	COMBUF_INFO	*info;
	COMBUFP	bufp;

	if (!(HANDLE_CHECK(handle)))
		return	NULL;

	info = &infotbl[handle];
    if (Queue_receive( info->que_alloc, &bufp, ptt) ==  pdTRUE) {
//	if (xQueueReceive( info->que_alloc, &bufp, ptt) ==	pdTRUE)	{
		//
		bufp->cominfo_handle = handle;
		bufp->lock = 0;
		//
		if (info->hookfunc)
		   (*info->hookfunc)(CMBFHF_ALLOC, info->hf_param);
		return	bufp;
	}
	return	NULL;
}

// =========================================================
// 決められたメモリサイズでメモリブロックを取得します。
//
COMBUFP	combuf_alloc_FromIsr(COMBUFHANDLE handle)
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	COMBUF_INFO	*info;
	COMBUFP	bufp;

	if (!(HANDLE_CHECK(handle)))
		return	NULL;

	info = &infotbl[handle];
	if (Queue_receiveFromISR( info->que_alloc, &bufp, &xHigherPriorityTaskWoken) ==	pdTRUE)	{
//    if (xQueueReceiveFromISR( info->que_alloc, &bufp, &xHigherPriorityTaskWoken) == pdTRUE) {
		//
		bufp->cominfo_handle = handle;
		bufp->lock = 0;
		//
		if (info->hookfunc)
		   (*info->hookfunc)(CMBFHF_ALLOC, info->hf_param);
		return	bufp;
	}
	return	NULL;
}

// =========================================================
// 取得したメモリブロックを破棄されないように、ロックします
//
int	combuf_lock(COMBUFP	bufp)
{

	if (!(HANDLE_CHECK((COMBUFHANDLE)bufp->cominfo_handle))) // バッファの正当性を確認
		return	ERR;

	++bufp->lock;
	return SUCCESS;
}

// =========================================================
// 取得したメモリブロックを破棄します。
//
int combuf_free(COMBUFP	bufp, TickType_t ptt)
{
	COMBUF_INFO	*info;

	if (!(HANDLE_CHECK((COMBUFHANDLE)bufp->cominfo_handle))) // バッファの正当性を確認
		return	ERR;

	if (bufp->lock) {
		--bufp->lock;
		return SUCCESS;
	}
	info = &infotbl[bufp->cominfo_handle];
    if (Queue_send(info->que_alloc, (void *)&bufp, ptt) != pdTRUE)
//	if (xQueueSend(info->que_alloc, (void *)&bufp, ptt) != pdTRUE)
		return	ERR;

	if (info->hookfunc)
	   (*info->hookfunc)(CMBFHF_FREE, info->hf_param);

	return SUCCESS;
}


// =========================================================
// 取得したメモリブロックを破棄します。
//
int	combuf_free_FromIsr(COMBUFP	bufp )
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	COMBUF_INFO	*info;

	if (!(HANDLE_CHECK((COMBUFHANDLE)bufp->cominfo_handle))) // バッファの正当性を確認
		return	ERR;

	if (bufp->lock) {
		--bufp->lock;
		return	SUCCESS;
	}
	info = &infotbl[bufp->cominfo_handle];
    if (Queue_sendIRS(info->que_alloc, (void *)&bufp, &xHigherPriorityTaskWoken) != pdTRUE)
//	if (xQueueSendFromISR(info->que_alloc, (void *)&bufp, &xHigherPriorityTaskWoken) != pdTRUE)
		return	ERR;

	if (info->hookfunc)
	   (*info->hookfunc)(CMBFHF_FREE, info->hf_param);

	return	SUCCESS;
}

// =========================================================
// 解放されているカウント返す。
//
int	combuf_free_count(
  COMBUFHANDLE comtblcnt)	//	共有メモリ管理ハンドル
{
	COMBUF_INFO	*info;

	if	(!(HANDLE_CHECK(comtblcnt)))
		return	ERR;

	info = &infotbl[comtblcnt];
    return xQueueMessagesWaiting(info->que_alloc);
//    return xQueueMessagesWaiting(info->que_alloc);
}

// =========================================================
//
QueueHandle_t combuf_get_quehandle(
  COMBUFHANDLE comtblcnt)	//	共有メモリ管理ハンドル
{
	COMBUF_INFO	*info;
	if	(!(HANDLE_CHECK(comtblcnt)))
		return	(QueueHandle_t)ERR;
	info = &infotbl[comtblcnt];

	return	info->que_alloc;
}

// =========================================================
//
// =========================================================

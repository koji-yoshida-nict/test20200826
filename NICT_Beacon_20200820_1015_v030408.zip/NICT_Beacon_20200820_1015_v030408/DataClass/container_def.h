/* ========================================================
 * container_def.h
 *
 *  Created on: 2016/12/13
 *      Author: t.miki
 ========================================================== */

#ifndef DATACLASS_CONTAINER_DEF_H_
#define DATACLASS_CONTAINER_DEF_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef USE_FREERTOS
// =========================================================
// FreeRTOS ヘッダ
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>
#include <queue.h>

// =========================================================
// typedef
typedef SemaphoreHandle_t Semaphore_Handle ;
typedef TaskHandle_t Task_Handle ;
typedef QueueHandle_t Queue_Handle ;

#define Queue_create(a1,a2) xQueueCreate(a1,a2)
#define Queue_send(a1,a2,a3) xQueueSend(a1,a2,a3)
#define Queue_receive(a1,a2,a3) xQueueReceive(a1,a2,a3)
#define Queue_sendIRS(a1,a2,a3) xQueueSendFromISR(a1,a2,a3)

#define Semaphore_pend(x,y) xSemaphoreTake(x,y)
#define BIOS_WAIT_FOREVER 0xffff

#define ctTick TickType_t
#define ctBase BaseType_t

#else
// =========================================================
// tirtos
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Queue.h>
//#include "util.h"

// =========================================================
// typedef

typedef Semaphore_Handle SemaphoreHandle_t ;
typedef Task_Handle TaskHandle_t ;
typedef Queue_Handle QueueHandle_t ;

//#define Task_Create(a1,a2,a3,a4,a5,a6) Task_create(a1,a2,a3,a4,a5,a6)
//#define Queue_Create(a1,a2) Queue_create(NULL,NULL)
#define Queue_Create(a1,a2) Queue_create(a1,a2)

////#define Queue_send(a1,a2,a3) Queue_enqueue(a1,a2)
////#define Queue_receive(a1,a2,a3) Queue_dequeue(a1,a2)
////#define Queue_sendIRS(a1,a2,a3) Queue_enqueue(a1,a2)

//#define Queue_enqueue(a1,a2)
//#define Queue_dequeue(a1,a2)
//#define Semaphore_pend(x,y) xSemaphoreTake(x,y)

//#define BIOS_WAIT_FOREVER 0xffff

#endif
//#include "combuf_man.h"

// =========================================================
// Queue Class
// =========================================================

//#define CONTAINER_MAX       COMBUF_INFOMAX       // task num * 2
//#define CONTAINER_MAX       10         // task num * 2
#define MAX_QUEUE_ELEM      8        /* Max Queue element number */
#define MAX_QUEUE_SIZE      20       /* Max Row*/

// =========================================================
//
#define CONTAINER_MESSAGE_LEN (280)
//#define CONTAINER_MESSAGE_LEN (255+1)
//#define CONTAINER_MESSAGE_LEN (64+1)
//#define CONTAINER_MESSAGE_LEN (1024+1)
#define MESSAGE_DATA_LEN CONTAINER_MESSAGE_LEN

// =========================================================
//
typedef struct __attribute__((__packed__)) tag_Message_t
{
    uint8_t creator ;               // creat task ID
    uint8_t terminater ;            // terminate task ID
    uint8_t property;               // property ( Proc )
    uint8_t type;                   // type Msg/Data
    uint16_t length;                // data length
    uint8_t data[CONTAINER_MESSAGE_LEN];        // 32Byte
} MessageObj, *Message_t;

#define CONTAINER_DATA_LEN (1024+1)
// =========================================================
//
typedef struct __attribute__((__packed__)) tag_Data_t
{
    uint8_t creator ;               // creat task ID
    uint8_t terminater ;            // terminate task ID
    uint8_t property;               // property ( Proc )
    uint8_t type;                   // type Msg/Data
    uint16_t length;                // data length
    uint8_t data[CONTAINER_DATA_LEN];               // 2KByte
} DataObj, *Data_t;

// =========================================================
//
//typedef union tag_Container_Obj
typedef struct __attribute__((__packed__)) tag_Container_Obj
{
    // =========================================================
    // combuf I/F
    uint8_t cominfo_handle;
    uint8_t lock;

    // =========================================================
    // container
    MessageObj      Msg ;
//  Message_t       Meg_t ;
//  Data_t          Data_t ;
//  void *          Obj ;
}ContainerObj, *ContainerObj_t ,ContainerObj_[];
typedef  int16_t   Container_Handle;       // コンテナハンドル

// =========================================================
//
// ====================================================
//
// ====================================================
/* FIFO Data Type */

typedef ContainerObj *COMBUFP ;
typedef Container_Handle COMBUFHANDLE ;

typedef COMBUFHANDLE Fifo_Handle ;
typedef ContainerObj_t fifo_data_t;

#define MAX_FIFO_ELEM CONTAINER_MAX /* Max Queue element number */
#define FIFO_SIZE QUEUE_SIZE    /* Max Row*/

#endif /* DATACLASS_CONTAINER_DEF_H_ */

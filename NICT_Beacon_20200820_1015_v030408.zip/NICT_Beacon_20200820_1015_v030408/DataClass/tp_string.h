/*
 * tp_string.h
 *
 *  Created on: 2016/08/31
 *      Author: amatsuda
 */

#ifndef MPI_WIFI_SRC_COMMON_TP_STRING_H_
#define MPI_WIFI_SRC_COMMON_TP_STRING_H_


extern int tsprintf(char* ,char* , ...);
extern int vtsprintf(char* buff,char* fmt,va_list arg);


#endif /* MPI_WIFI_SRC_COMMON_TP_STRING_H_ */

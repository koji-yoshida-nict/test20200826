//******************************************************************************
// file		queueContainer.h
// brief	キューコンテナ ヘッダ
// writer	t.miki 2016.12.12
//******************************************************************************
#ifndef _QUEUE_CONTAINER_H_
#define _QUEUE_CONTAINER_H_

#include <stdint.h>
#include <stdbool.h>

#include "application/app_version.h"

#ifdef USE_FREERTOS
// =========================================================
// FreeRTOS ヘッダ
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>
#include <queue.h>

//#include "c_queue.h"
#include "conteiner_def.h"

// =========================================================
// typedef
#define BIOS_WAIT_FOREVER 0xffff

#else

#include <ti/sysbios/knl/Queue.h>
#include <ti/sysbios/knl/Task.h>
//#include "util.h"

#include "container_def.h"
#define ERR  -1

#endif

// =========================================================
// コンテナハンドル

// =========================================================
// コンテナデータ
typedef struct __attribute__((__packed__))
{
  Queue_Handle		handle;			// MsgQueueハンドル (Queue Handle)
  Fifo_Handle       cbhandle;		// buffHandle
  uint16_t			length;			// buffer length
  uint8_t			Row;			// データ数
//  ContainerObj_t	pData;			// データ位置ポインタ
} ContainerData, *ContainerData_t;

// -----------------------------------------------------------------------------
// brief	コンテナ生成
// param	array	コンテナ領域ﾃﾞｰﾀアドレス
//			maxRow	コンテナ領域コンテナ数
// ret		コンテナハンドル
// -----------------------------------------------------------------------------
Container_Handle Container_create(uint16_t length, uint16_t maxRow);

// -----------------------------------------------------------------------------
// brief	Get Queue Handle
// param	Container_Handle ctHandle
// ret		Queue ハンドル
// -----------------------------------------------------------------------------
Queue_Handle Container_GetQueueHandle(Container_Handle conHandle);

// -----------------------------------------------------------------------------
// brief   コンテナ取得
// param   conHandle コンテナハンドル
// ret     コンテナデータアドレス
// -----------------------------------------------------------------------------
ContainerObj_t Container_alloc(Container_Handle conHandle);
ContainerObj_t Container_alloc_isr(Container_Handle conHandle);

// -----------------------------------------------------------------------------
// brief	コンテナ返却
// param	conHandle   コンテナハンドル
// param	conDataAddr コンテナデータアドレス
// ret		コンテナポインタ
// -----------------------------------------------------------------------------
bool Container_free(ContainerObj_t ctObj);
bool Container_free_isr(ContainerObj_t ctObj);

#endif // _QUEUE_CONTAINER_H_

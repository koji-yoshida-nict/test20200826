//	簡易的にメモリを割り当てる
//	動的割り当てだが、解放はできない。
//	プログラムの起動時に割り当てる

#include "tp_stddef.h"
#include "esymalloc.h"

static uint8_t esy_Heap[configESY_HEAP_SIZE];

// 20160425 H.Satoh Mod
static uint16_t nowsize = 0;

void *esy_malloc(uint16_t size)
{
	void *alcp;

	if ((nowsize + size) > configESY_HEAP_SIZE)
		return	0;
	alcp	=	&esy_Heap[nowsize];
	nowsize	+=	size;
	return	alcp;
}

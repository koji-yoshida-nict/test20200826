// 簡易的にメモリを割り当てる
// 動的割り当てだが、解放はできない。
// プログラムの起動時に割り当てる

#include "application/app_version.h"
//#define	configESY_HEAP_SIZE	8000

void *esy_malloc(uint16_t);

#define	_MALLOC(s) esy_malloc( s )

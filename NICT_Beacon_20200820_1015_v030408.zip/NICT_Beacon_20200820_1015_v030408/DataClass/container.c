//******************************************************************************
// file		queueContainer.c
// brief	キューコンテナ
// writer	t.ishibashi 2016.08.02
//******************************************************************************
//#include <ICall.h>
//#include "Debug.h"
#include "container.h"
#include "combuf_man.h"

static ContainerData Container[CONTAINER_MAX] ;

// -----------------------------------------------------------------------------
// brief	コンテナ生成
// param	array  コンテナ領域2次元配列アドレス
//          length    コンテナ幅
//			maxRow    コンテナ領域コンテナ数
// ret		コンテナハンドル
// -----------------------------------------------------------------------------
Container_Handle Container_create(uint16_t length, uint16_t maxRow)

{
	Queue_Handle xQHandle ;
	Container_Handle ctHandle ;
	uint16_t size = sizeof(ContainerObj_t) ;

	if (maxRow > 0){
	    // =========================================================
	    // Msg キューを生成
		if ((xQHandle = Queue_Create( maxRow , size ))){
//        if ((xQHandle = xQueueCreate( maxRow , size ))){
		    ctHandle = combuf_create( length , maxRow);
			if (ctHandle == ERR ) {
				// TODO											// combuf create エラー
				while(1);
			}
			if (combuf_clear(ctHandle) == -1) {
				// TODO											// combuf 初期化エラー
				while(1);
			}
			if (xQHandle != NULL){
            	Container[ctHandle].handle = xQHandle ;
        	    Container[ctHandle].length = length ;
        	    Container[ctHandle].Row = maxRow ;
           	    Container[ctHandle].cbhandle = ctHandle ;
//        	    CtObjIndex[ctHandle] = 0 ;
            }
		}
	}
	return ctHandle;
}

// -----------------------------------------------------------------------------
// brief	コンテナ取得
// param	conHandle コンテナハンドル
// ret		コンテナデータアドレス
// -----------------------------------------------------------------------------
Queue_Handle Container_GetQueueHandle(Container_Handle ctHandle)
{
	return Container[ctHandle].handle ;
}

// -----------------------------------------------------------------------------
// brief	コンテナ取得
// param	conHandle コンテナハンドル
// ret		コンテナデータアドレス
// -----------------------------------------------------------------------------
ContainerObj_t Container_alloc(Container_Handle ctHandle)
{
	Fifo_Handle cbHandle ;
	ContainerObj_t ctObj = NULL;

	if( ctHandle>=0 ){
		cbHandle = Container[ctHandle].cbhandle ;

		ctObj = combuf_alloc_nonb( cbHandle ) ;
//DBG_PRINT("combuf_alloc_nonb: 0x%x \n\r",ctObj) ;
		ctObj->Msg.creator = 0 ;
		ctObj->Msg.terminater = 0 ;
		ctObj->Msg.property = 0 ;
		ctObj->Msg.length = Container[ctHandle].length;
	}
	return  ctObj ;
}

// -----------------------------------------------------------------------------
// brief	コンテナ取得
// param	conHandle コンテナハンドル
// ret		コンテナデータアドレス
// -----------------------------------------------------------------------------
ContainerObj_t Container_alloc_isr(Container_Handle ctHandle)
{
	Fifo_Handle cbHandle ;
	ContainerObj_t ctObj = NULL;

	if( ctHandle>=0 ){
		cbHandle = Container[ctHandle].cbhandle ;
		ctObj = combuf_alloc_nonb( cbHandle ) ;
//		ctObj = combuf_alloc_isr( cbHandle ) ;
//DBG_PRINT("combuf_alloc_nonb: 0x%x \n\r",ctObj) ;

//		ctObj = combuf_alloc_isr( cbHandle ) ;
		ctObj->Msg.creator = 0 ;
		ctObj->Msg.terminater = 0 ;
		ctObj->Msg.property = 0 ;
		ctObj->Msg.length = Container[ctHandle].length;
	}
	return  ctObj ;
}

// -----------------------------------------------------------------------------
// brief	コンテナ返却
// param	conHandle   コンテナハンドル
// param	conDataAddr コンテナデータアドレス
// ret		TRUE or FALSE
// -----------------------------------------------------------------------------
bool Container_free(ContainerObj_t ctObj)
{
	// ====================================================
	// free buffer
//DBG_PRINT("Container_free: 0x%x \n\r",ctObj) ;
	combuf_free_nonb(ctObj);
    return true;
}

bool Container_free_isr(ContainerObj_t ctObj)
{
	// ====================================================
	// free buffer
//DBG_PRINT("Container_free: 0x%x \n\r",ctObj) ;
	combuf_free_isr(ctObj);
    return true;
}

// ====================================================
// end of file
// ====================================================

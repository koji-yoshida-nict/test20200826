//	標準的な値を定義
#include <stdint.h>

#ifndef	TP_STDDEF_H
#define	TP_STDDEF_H

#define	D_TRUE	1
#define	D_FALSE	0

#define	ERR		-1
#define	SUCCESS	0

#undef FALSE
#define FALSE 0

#undef TRUE
#define TRUE 1

#endif	//	TP_STDDEF_H

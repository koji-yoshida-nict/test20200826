/******************************************************************************
  Filename:       commonData.h
  Revised:        Date: 2016.07.12 ishibashi
******************************************************************************/
#ifndef _COMMONDATA_H_
#define _COMMONDATA_H_

#ifdef __cplusplus
extern "C"
{
#endif

// ****************************************************************************
// includes
// ****************************************************************************
#include <stdint.h>

// ****************************************************************************
// defines
// ****************************************************************************
#define UART_STX_LEN      (1) // STX length include DLE
#define UART_ETX_LEN      (1) // ETX length include DLE
#define UART_DATASIZE_LEN (1) // data size length
#define UART_SUM_LEN      (1) // checksum length
#define UART_HEADER_LEN   (UART_STX_LEN \
                         + UART_DATASIZE_LEN)  // Header length
#define UART_FOOTER_LEN   (UART_ETX_LEN \
                         + UART_SUM_LEN)        // Footer length

#define CR                 0x0d
#define LF                 0x0a

// ****************************************************************************
// typedefs
// ****************************************************************************
// �R���e�i�������
typedef enum {
  CREATOR_ID_MANAGE = 0x01,
  CREATOR_ID_AIR,
  CREATOR_ID_WIRE,
  CREATOR_ID_TEST
} eCreatorInfo;

// startup mode
typedef enum
{
    STARTUPMODE_NORMAL = 0x00,
    STARTUPMODE_TEST
} eStartupMode;

typedef enum {
	CTRL_CODE_STX = 0x02,       // STX
	CTRL_CODE_ETX = 0x03,       // ETX
	CTRL_CODE_DLE = 0x10,       // DLE
	CTRL_CODE_DELIMITER = CR    // Delimiter
} eControlCode;

typedef enum {
	PACKET_SEARCH_DLE_MODE = 0, // search packet header-dle mode
	PACKET_SEARCH_STX_MODE,     // search packet header-stx mode
	PACKET_BUILD_MODE,          // build packet mode
	PACKET_BUILD_DLE_MODE,      // build packet found dle mode
	PACKET_BUILD_FINISH_MODE    // build packet finish mode
} ePacketBuildStatus;

//*****************************************************************************
// globals
//*****************************************************************************

//*****************************************************************************
// function prototypes
//*****************************************************************************

#ifdef __cplusplus
}
#endif

#endif /* _COMMONDATA_H_ */


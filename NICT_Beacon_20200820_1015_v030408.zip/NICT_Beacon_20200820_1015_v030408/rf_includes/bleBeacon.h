#ifndef BLEBEACON_H_
#define BLEBEACON_H_

#ifdef __cplusplus
extern "C"
{
#endif

/*********************************************************************
 * INCLUDES
 */
#include <stdint.h>
#include <stdbool.h>

/*********************************************************************
*  EXTERNAL VARIABLES
*/

/*********************************************************************
 * CONSTANTS
 */


/*********************************************************************
 * TYPEDEFS
 */
/// \brief BLE Beacon Status and error codes
typedef enum
{
    bleBeacon_Status_Success         = 0, ///Success
    bleBeacon_Status_Config_Error    = 1, ///Configuration error
    bleBeacon_Status_Param_Error     = 2, ///Param error
    bleBeacon_Status_Tx_Error        = 5, ///Tx Error
    bleBeacon_Status_Rx_Error        = 6, ///Tx Error
} bleBeacon_Status;

/// \brief Structure for the BLE Advertisement Packet
typedef struct
{
    uint8_t *deviceAddress;       ///Device Address used used in the
                                  ///rfc_CMD_BLE_ADV_NC_t Rf command
    uint8_t length;               ///Advertisement packet length
    uint8_t *pAdvData;            ///Advertisement data
} bleBeacon_Frame;

/// \brief advertisement interval array in 100us units, optimised for iOS.
///        iOS guidlines state 152.5ms 211.25ms 318.75ms 417.5ms 546.25ms
///        760ms 852.5ms 1022.5ms and 1285ms. In this application we can
///        only advertise for 1s as the sub1G packet rate can be as high
///        as every 1s.
extern uint32_t bleBeacon_AdvertisementIntervals[];

/// \brief default advertisement interval default 100us units, used when
///        advertisement times exceeds the elements in the
///        bleBeacon_AdvertisementIntervals array
#define bleBeacon_DefaultAdvertisementInterval 1000

/// \brief number of advertisement packets sent in 1 period.
#define bleBeacon_AdvertisementTimes  10

/*********************************************************************
 * FUNCTIONS
 */

//*****************************************************************************
//
//! \brief Initialise the bleBeacon module
//!
//! Initialise the bleBeacon module.
//!
//! \param multiClient ued to set multiClient rfMode if there will be multiple
//!                    RF driver clients
//!
//! \return bleBeacon_Status
//!
//*****************************************************************************
extern bleBeacon_Status bleBeacon_init(bool multiClient);

//*****************************************************************************
//
//! \brief Gets the IEEE address
//!
//! This function gets the IEEE address
//!
//! \param ieeeAddr pointer to a 6 element byte array to write the IEEE
//! address to.
//!
//! \return bleBeacon_Status
//!
//*****************************************************************************
extern bleBeacon_Status bleBeacon_getIeeeAddr(uint8_t *ieeeAddr);

//*****************************************************************************
//
//! \brief Closes the bleBeacon module
//!
//! Closes the bleBeacon module.
//!
//!
//! \return bleBeacon_Status
//!
//*****************************************************************************
extern bleBeacon_Status bleBeacon_close(void);

//*****************************************************************************
//
//! \brief Send a beacon
//!
//! This function transmits a beacon using the RF driver commands
//!
//! \param beaconFrame Beacon to be advertised
//! \param numTxPerChan Number of transmits per channel
//! \param chanMask channel mask of channels to advertise on
//!
//! \return bleBeacon_Status
//!
//*****************************************************************************
extern bleBeacon_Status bleBeacon_sendFrame(bleBeacon_Frame beaconFrame, uint32_t numTxPerChan, uint64_t chanMask);

/*********************************************************************
*********************************************************************/

#ifdef __cplusplus
}
#endif

#endif /* BLEBEACON_H_ */

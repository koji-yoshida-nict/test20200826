#ifndef WISUNBEACON_H_
#define WISUNBEACON_H_

#ifdef __cplusplus
extern "C"
{
#endif

/*********************************************************************
 * INCLUDES
 */
#include <stdint.h>
#include <stdbool.h>

/*********************************************************************
*  EXTERNAL VARIABLES
*/

/*********************************************************************
 * CONSTANTS
 */


/*********************************************************************
 * TYPEDEFS
 */
/// \brief BLE Beacon Status and error codes
typedef enum
{
    wiSunBeacon_Status_Success         = 0, ///Success
    wiSunBeacon_Status_Config_Error    = 1, ///Configuration error
    wiSunBeacon_Status_Param_Error     = 2, ///Param error
    wiSunBeacon_Status_Aborted         = 3, // aborted
    wiSunBeacon_Status_Cmd_Error       = 4, // cmd error
    wiSunBeacon_Status_Tx_Error        = 5, ///Tx Error
    wiSunBeacon_Status_Rx_Error        = 6, ///Tx Error
	wiSunBeacon_Status_Error,
} wiSunBeacon_Status;


typedef struct
{
    uint8_t length;               ///Advertisement packet length
    uint8_t *pAdvData;            ///Advertisement data
} wiSunBeacon_Frame;


/*********************************************************************
 * FUNCTIONS
 */
extern wiSunBeacon_Status wiSunBeacon_init(bool multiClient);
extern wiSunBeacon_Status wiSunBeacon_close(void);
extern wiSunBeacon_Status wiSunBeacon_SetTXPower(int8_t pow);
extern wiSunBeacon_Status wiSunBeacon_sendToFrame(wiSunBeacon_Frame *beaconFrame, uint32_t numTxPerChan);
extern wiSunBeacon_Status wiSunBeacon_sendFrame();

extern wiSunBeacon_Status wiSunBeacon_getIeeeAddr(uint8_t *ieeeAddr);

/*********************************************************************
*********************************************************************/

#ifdef __cplusplus
}
#endif

#endif /* WISUNBEACON_H_ */

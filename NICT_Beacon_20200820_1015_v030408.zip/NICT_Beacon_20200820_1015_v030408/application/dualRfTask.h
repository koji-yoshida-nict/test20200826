#ifndef DUAL_RF_TASK_H_
#define DUAL_RF_TASK_H_

#include "stdint.h"
#include "stdbool.h"


// =========================================================
void dualRfTask_init(void);
void SendRf();
#endif /* DUAL_RF_TASK_H_ */

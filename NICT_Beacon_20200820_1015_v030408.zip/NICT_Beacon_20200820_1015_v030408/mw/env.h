// =========================================================
//
//	工場出荷時の環境変数領域
//
#ifndef	ENV_H
#define	ENV_H
#include "DataClass/tp_stddef.h"

#include "env_nict.h"
// =========================================================
//
//	アプリケーション用環境変数領域
//
#define ENV_WATERMARK_CODE      'L'
#define FLASH_SECNO_NICT        30

extern const uint8_t            title[];
extern const uint8_t            ver[];
extern ENV_NICTPARAM            env_nictparam;

int environ_recall_nict();
extern int environ_read_nict();
extern int environ_write_nict();

#endif	//	ENV_H

// =========================================================
// - end of file
// =========================================================

// =========================================================
//
//	レジスタテーブルの定義
//
#ifndef REG_H
#define REG_H

#include "DataClass/container.h"

//#define REG_BYTE      -1
//#define REG_WORD      -2
//#define REG_DWORD     -4
typedef struct  __attribute__((__packed__)) tagREG_MEM
{
    uint8_t     regno;      //	レジスタ番号
    uint8_t     regatb;     //	レジスタ種別
    void        *data;      //	データポインタ
    uint8_t     l1regno;    //	L1レジスタ番号
    uint32_t    min;        //	設定最小値
    uint32_t    max;        //	設定最大地
    int         (*getfunc)(struct tagREG_MEM*, PKBASEHED* pMsgQue); // リード関数
    int         (*putfunc)(struct tagREG_MEM*, PKBASEHED* pMsgQue); // ライト関数
} REG_MEM;

const REG_MEM *tbl_search(uint8_t regno);
#endif  //REG_H

/* =========================================================
 * env.c
 *
 *  Created on: 2017/01/30
 *      Author: t.miki
 *
 *  Copyright (C) 2016 Telepower .inc
 * =========================================================*/
#include "application/app_version.h"

//	環境変数の書き込みについて
#include "env.h"
#include "flash_read_write.h"

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/Assert.h>
#include <xdc/runtime/System.h>

/* DriverLib Header files */
#include <driverlib/flash.h>
#include <driverlib/vims.h>

//Primary IEEE address location
#define WISUN_PRI_IEEE_ADDR_LOCATION    0x500012F0
//Secondary IEEE address location
#define WISUN_SEC_IEEE_ADDR_LOCATION    0x0001FFC8
// Primary ADDRESS BLE
#define BLE_PRI_IEEE_ADDR_LOCATION      0x500012E8
// Secondary ADDRESS BLE
#define BLE_SEC_IEEE_ADDR_LOCATION      0x500012D0

ENV_NICTPARAM   env_nictparam;

/* PROTO TYPE */
void setBleIeeeAddr();
void setWisunIeeeAddr();

//////////////////  デファルト値の規定   /////////////////////
static const ENV_NICTPARAM env_nict_def =
{
    .wiSunCh1               = 0x23,         // Ch1 37
    .wiSunCh2               = 0x2B,         // Ch2 43
    .wiSunCh3               = 0x3B,         // Ch3 59

    .burstCh                = 0xff,         // Wi-SUN バーストCH 37
//    .burstCh                = 0x3B,         // Wi-SUN バーストCH 59

//    .deviceRunmode          = 0x01,         // 0x00:定期発信モード/その他:イベント発信モード
//    .deviceRunmode          = 0x00,         // 0x00:定期発信モード/その他:イベント発信モード
    .deviceRunmode          = DEVICE_RUNMODE_EVENT | DEVICE_RUNMODE_TIMER,
//    .deviceRunmode          = DEVICE_RUNMODE_TIMER ,
//    .beaconExist              = 0x03,         // ble/wisun 有効
//    .beaconExist              = BEACON_BLE_ENABLE | BEACON_WISUN_ENABLE,         // ble/wisun 有効
    .beaconExist              = BEACON_WISUN_ENABLE | BEACON_BLE_ENABLE ,         // ble/wisun 有効
//    .beaconExist            = 0x0F,         // 0x01:BLE 0x02;Wi-SUN 0x04:Wi-SUN Burst 0x08:BLE Burst
    .WiSUNBaseBeaconEn      = 0x01,         // Wi-SUN Beacon定期発信有効設定   0x0/0x01

    .WiSUNBaseInterval      = 150,           // Wi-SUN 定期発信間隔(100msec) 15sec
    .WiSUNBurstPeriod       = 10,           // Wi-SUN バースト周期 (300msec) 定期発信（Ch1->Ch2->Ch3切替時間と共用）
    .WiSUNBurstCount        = 0,            // Wi-SUN バースト回数
    .bleBaseBeaconEn        = 0x01,         // bleBeacon定期発信有効設定   0x0/0x01
    .bleBaseInterval        = 50,           // 定期発信間隔(100msec) 1sec    (1sec -> 9sec)
//    .bleBaseInterval        = 1,           // 定期発信間隔(100msec) 1sec    (1sec -> 9sec)
    .bleBurstPeriod         = 10,           // bleバースト周期(100msec)
    .bleBurstCount          = 0,            // bleバースト回数
    
    .WiSUNExist             = {0x2C,0x3F},
//    .WiSUNExist             = {0xFF,0xFF},
    .bleExist               = {0x24,0x10},
//    .bleExist               = {0x00,0x2D},
// ------------------------------------------------------------------------------
    .vendor1                = 0x00,
    .vendor2                = 0x00,
    .vendor3                = 0x00,

    .WiSUNPayloadPanidNormal= 0xED00,       // Wi-SUN PANID 通常モード
    .WiSUNPayloadPanidWalk  = 0xC000,       // Wi-SUN PANID イベントモード 歩行
    .WiSUNPayloadPanidRun   = 0xC001,       // Wi-SUN PANID イベントモード 走行

    .blePayloadPanidNormal  = 0xED00,       // BLE PANID 通常モード
    .blePayloadPanidWalk    = 0xC000,
    // BLE PANID イベントモード 歩行
    .blePayloadPanidRun     = 0xC001,       // BLE PANID イベントモード 走行

    .WiSUNPayloadPanid      = 0xED00,
    .WiSUNPayloadName       = {"WiWiED00"},
//    .WiSUNPayloadFlag       = 0x0120,
    .WiSUNPayloadFlag       = 0x1120,       // SCF On
    .WiSUNPayloadHop        = 0,
    .WiSUNPayloadSequence   = 0,
    .WiSUNPayloadPepiod     = 10,
    .WiSUNPayloadSendid     = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    .WiSUNPayloadServid     = 0x03,
    .WiSUNPayloadDestid     = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    .WiSUNPayloadHopmax     = 2,
    .WiSUNPayloadDistance   = 4e20,
    .WiSUNPayloadTime       = {0x00,0x00,0x3C},
    .WiSUNPayloadVoltage    = 0,
    .WiSUNPayloadActStat    = 0,
    .WiSUNPayloadAccdata    = 0,

    .blePayloadPanid        = 0xED00,
    .blePayloadName         = {"WiWiED00"},
//    .blePayloadFlag         = 0x0140,
    .blePayloadFlag         = 0x0140,   // SCF On
    .blePayloadHop          = 0,
    .blePayloadSequence     = 0,
    .blePayloadPepiod       = 50,
    .blePayloadSendid       = {0x00,0x00,0x00,0x00,0x00,0x00},
    .blePayloadServid       = 0x00,
    .blePayloadDestid       = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    .blePayloadHopmax       = 8,
    .blePayloadDistance     = 2000,
    .blePayloadTime         = {0x00,0x00,0x3C},
    .blePayloadVoltage      = 0,
    .blePayloadActStat      = 0,
    .blePayloadAccdata      = 0,

    .accDynamicRange        = 0x00,
    .accSampringPeriod      = 0x03,

    .activeWindowData       = 50,
    .activeWindowNumber     = 7,

    .sleepWakeupValue       = 10,
//    .sleepWakeupValue       = 20,
    .sleepJudgeValue        = 10,
//    .sleepJudgeValue        = 60,
    .sleepJudgeNumber       = 0x7,

    .walkJudgeValue         = 18,
//    .walkJudgeValue         = 30,
    .walkJudgeNumber        = 2,
    .walkWisunInterval      = 100,
    .walkWisunBurstPeriod   = 0x1E,
    .walkWisunBurstCount    = 0x03,
    .walkBleInterval        = 50,
    .walkBleBurstPeriod     = 0x0A,
    .walkBleBurstCount      = 0x01,

    .runJudgeValue          = 50,
//    .runJudgeValue          = 40,
    .runJudgeNumber         = 1,
    .runWisunInterval       = 50,
    .runWisunBurstPeriod    = 0x1E,
    .runWisunBurstCount     = 0x03,
    .runBleInterval         = 10,
    .runBleBurstPeriod      = 0x0A,
    .runBleBurstCount       = 0x01,

    // ------------------------------------------------------------------------------
    // NICT #MOD_190917
    .WiSUNLifeCount         = 1440,         // Wi-SUN  LifeCount < WiSUNBaseInterval x g_LifeCounter
    .WiSUNDeathCount        = 1440,
    .WiSUNSublifeCount      = 480,
    .WiSUNSystemRebootCount = 40320,
    
    .preamble               = 0x15,
    .syncword               = 0x904e,
};

int environ_recall_nict()
{
    env_nictparam = env_nict_def;
    setBleIeeeAddr();
    setWisunIeeeAddr();

    return 0;
}

int environ_read_nict()
{
    flash_read( FLASH_SECNO_NICT, (unsigned char*)&env_nictparam, sizeof(ENV_NICTPARAM) );

    if(env_nictparam.watermark != ENV_WATERMARK_CODE)
    {
        environ_recall_nict();
        return  ERR;
    }
    return  SUCCESS;
}

int environ_write_nict()
{
//    updateMemoryInFlash(&configInFlash, &configInRam, sizeof(ApplicationConfig));
    env_nictparam.watermark = ENV_WATERMARK_CODE;
    return flash_write( FLASH_SECNO_NICT, (unsigned char*)&env_nictparam, sizeof(ENV_NICTPARAM) );
}

void setBleIeeeAddr()
{
    int i;

    //Reading from primary IEEE location...
    uint8_t *location = (uint8_t *)BLE_PRI_IEEE_ADDR_LOCATION;

    /*
     * ...unless we can find a byte != 0xFF in secondary
     *
     * Intentionally checking all 6 bytes here instead of len, because we
     * are checking validity of the entire IEEE address irrespective of the
     * actual number of bytes the caller wants to copy over.
     */
    for (i = 0; i < BLE_ADDR_LEN; i++)
    {
        if (((uint8_t *)BLE_SEC_IEEE_ADDR_LOCATION)[i] != 0xFF)
        {
            //A byte in the secondary location is not 0xFF. Use the
            //secondary
            location = (uint8_t *)BLE_SEC_IEEE_ADDR_LOCATION;
            break;
        }
    }

    //inverting byte order
    for (i = 0; i < BLE_ADDR_LEN; i++)
    {
        env_nictparam.bleAddress[i] = location[BLE_ADDR_LEN - 1 - i];
        env_nictparam.blePayloadSendid[i] = location[BLE_ADDR_LEN - 1 - i];
    }
}

void setWisunIeeeAddr()
{
    int i;

    //Reading from primary IEEE location...
    uint8_t *location = (uint8_t *)WISUN_PRI_IEEE_ADDR_LOCATION;

    /*
     * ...unless we can find a byte != 0xFF in secondary
     *
     * Intentionally checking all 8 bytes here instead of len, because we
     * are checking validity of the entire IEEE address irrespective of the
     * actual number of bytes the caller wants to copy over.
     */
    for (i = 0; i < WISUN_ADDR_LEN; i++)
    {
        if (((uint8_t *)WISUN_SEC_IEEE_ADDR_LOCATION)[i] != 0xFF)
        {
            //A byte in the secondary location is not 0xFF. Use the
            //secondary
            location = (uint8_t *)WISUN_SEC_IEEE_ADDR_LOCATION;
            break;
        }
    }

    //inverting byte order
    for (i = 0; i < WISUN_ADDR_LEN; i++)
    {
        env_nictparam.wiSunAddress[i] = location[WISUN_ADDR_LEN - 1 - i];
        env_nictparam.WiSUNPayloadSendid[i] = location[WISUN_ADDR_LEN - 1 - i];
    }
}
// =========================================================
// - end of file
// =========================================================

/* ========================================================
 * fnet_i.h
 *
 *  Created on: 2017/02/01
 *      Author: t.miki
 * ======================================================== */

#ifndef APPLICATION_TASK_FNET_I_H_
#define APPLICATION_TASK_FNET_I_H_

// =========================================================

uint8_t uif_sendBlebeacon(msgBleAttachData_t *pkt,  uint8_t pkid);
uint8_t uif_sendWisunbeacon(msgWisunAttachData_t *pkt,  uint8_t pkid);

uint8_t uif_sendack(PKBASEHED *pkt, uint8_t pkid);
uint8_t uif_sendnack(PKBASEHED *pkt,uint8_t pkid,uint8_t errlen,uint8_t *errdat);

//void uif_sendresponce(xQueueHandle quehandle, uint8_t command, msgAttachData_t *attach);
void uif_sendresponce(PKBASEHED *pkt, uint8_t pkid, uint8_t datalen, uint8_t *dat);

#endif /* APPLICATION_TASK_FNET_I_H_ */
// =========================================================
// - end of file
// =========================================================

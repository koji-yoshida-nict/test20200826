// =========================================================
//
// レジスタコマンド 処理
// =========================================================
// 0x00
#define PKREG_RF_VER                    0x01
// =========================================================
// NICT REG
// =========================================================
// 0x1X Wi-SUN RF PARAMETER
#define PKREG_WISUN_CH1                 0x10
#define PKREG_WISUN_CH2                 0x11
#define PKREG_WISUN_CH3                 0x12
#define PKREG_WISUN_BURST_CH            0x13

// 0x2X BEACON PARAMETER
#define PKREG_DEVICE_RUNMODE            0x20
#define PKREG_BEACONMODE_EXIST          0x21

#define PKREG_WISUN_EXIST               0x22
#define PKREG_WISUN_PERIOD              0x23
#define PKREG_WISUN_INTERVAL            0x24
#define PKREG_WISUN_BURST_COUNT         0x25
#define PKREG_BLE_EXIST                 0x26
#define PKREG_BLE_PERIOD                0x27
#define PKREG_BLE_BURST_INTERVAL        0x28
#define PKREG_BLE_BURST_COUNT           0x29

// 0x3X PACKET基本情報
#define PKREG_PACKET_WISUN_EXISTS       0x30    // Wi-SUNパケット構成情報
#define PKREG_PACKET_BLE_EXISTS         0x31    // BLEパケット構成情報
#define PKREG_PACKET_VENDOR_1           0x32    //
#define PKREG_PACKET_VENDOR_2           0x33    //
#define PKREG_PACKET_VENDOR_3           0x34    //
#define PKREG_WISUN_PAYLOAD_PANID_DEF   0x35    // Wi-SUN PANID 通常モード
#define PKREG_WISUN_PAYLOAD_PANID_WALK  0x36    // Wi-SUN PANID イベントモード 歩行
#define PKREG_WISUN_PAYLOAD_PANID_RUN   0x37    // Wi-SUN PANID イベントモード 走行
#define PKREG_BLE_PAYLOAD_PANID_DEF     0x38    // BLE PANID 通常モード
#define PKREG_BLE_PAYLOAD_PANID_WALK    0x39    // BLE PANID イベントモード 歩行
#define PKREG_BLE_PAYLOAD_PANID_RUN     0x3A    // BLE PANID イベントモード 走行

// 0x4X Wi-SUN
#define PKREG_WISUN_PAYLOAD_PANID       0x40
#define PKREG_WISUN_PAYLOAD_NAME        0x41
#define PKREG_WISUN_PAYLOAD_FLAG        0x42    // フラグ
#define PKREG_WISUN_PAYLOAD_HOP         0x43    // ホップ数
#define PKREG_WISUN_PAYLOAD_SEQUENCE    0x44    // シーケンス番号
#define PKREG_WISUN_PAYLOAD_REPIOD      0x45    // 発信周期
#define PKREG_WISUN_PAYLOAD_SENDID      0x46    // 送信元デバイスID
#define PKREG_WISUN_PAYLOAD_SERVID      0x47    // サービスネットワークID
#define PKREG_WISUN_PAYLOAD_DESTID      0x48    // 宛先デバイスID
#define PKREG_WISUN_PAYLOAD_HOP_MAX     0x49    // 最大ホップ数
#define PKREG_WISUN_PAYLOAD_DISTANCE    0x4A    // 最大到達距離
#define PKREG_WISUN_PAYLOAD_TIME        0x4B    // 最大到達時間
#define PKREG_WISUN_PAYLOAD_VOLTAGE     0x4C    // 電源電圧
#define PKREG_WISUN_PAYLOAD_ACTSTAT     0x4D    // 動作判定
#define PKREG_WISUN_PAYLOAD_ACCDATA     0x4E    // 加速度センサー値

// 0x5X BLE
#define PKREG_BLE_PAYLOAD_PANID         0x50
#define PKREG_BLE_PAYLOAD_NAME          0x51
#define PKREG_BLE_PAYLOAD_FLAG          0x52    // フラグ
#define PKREG_BLE_PAYLOAD_HOP           0x53    // ホップ数
#define PKREG_BLE_PAYLOAD_SEQUENCE      0x54    // シーケンス番号
#define PKREG_BLE_PAYLOAD_REPIOD        0x55    // 発信周期
#define PKREG_BLE_PAYLOAD_SENDID        0x56    // 送信元デバイスID
#define PKREG_BLE_PAYLOAD_SERVID        0x57    // サービスネットワークID
#define PKREG_BLE_PAYLOAD_DESTID        0x58    // 宛先デバイスID
#define PKREG_BLE_PAYLOAD_HOP_MAX       0x59    // 最大ホップ数
#define PKREG_BLE_PAYLOAD_DISTANCE      0x5A    // 最大到達距離
#define PKREG_BLE_PAYLOAD_TIME          0x5B    // 最大到達時間
#define PKREG_BLE_PAYLOAD_VOLTAGE       0x5C    // 電源電圧
#define PKREG_BLE_PAYLOAD_ACTSTAT       0x5D    // 動作判定
#define PKREG_BLE_PAYLOAD_ACCDATA       0x5E    // 加速度センサー値

// 0x6X ACCELERATER PARAMETER
#define PKREG_ACC_DYNAMIC_RANGE         0x60
#define PKREG_ACC_SAMPRING_PERIOD       0x61

// 0x7X ACTIVEMODE COMMON PARAMETER (ACTIVE = WALK & RUN)
#define PKREG_ACTIVE_WINDOW_DATA        0x70
#define PKREG_ACTIVE_WINDOW_NUMBER      0x71

// 0x8X SLEEP MODE PARAMETER
#define PKREG_SLEEP_WAKEUP_VALUE        0x80
#define PKREG_SLEEP_JUDGE_VALUE         0x81
#define PKREG_SLEEP_JUDGE_NUMBER        0x82

// 0x9X WALK MODE PARAMETER
#define PKREG_WALK_JUDGE_VALUE          0x90
#define PKREG_WALK_JUDGE_NUMBER         0x91
#define PKREG_WALK_INTERVAL             0x92
#define PKREG_WALK_WISUN_BURST_PERIOD   0x93
#define PKREG_WALK_WISUN_BURST_COUNT    0x94
#define PKREG_WALK_BLE_INTERVAL         0x95
#define PKREG_WALK_BLE_BURST_PERIOD     0x96
#define PKREG_WALK_BLE_BURST_COUNT      0x97

// 0xAX RUN MODE PARAMETER
#define PKREG_RUN_JUDGE_VALUE           0xA0
#define PKREG_RUN_JUDGE_NUMBER          0xA1
#define PKREG_RUN_WISUN_INTERVAL        0xA2
#define PKREG_RUN_WISUN_BURST_PERIOD    0xA3
#define PKREG_RUN_WISUN_BURST_COUNT     0xA4
#define PKREG_RUN_BLE_INTERVAL          0xA5
#define PKREG_RUN_BLE_BURST_PERIOD      0xA6
#define PKREG_RUN_BLE_BURST_COUNT       0xA7

// 0xCX LIFE COUNT MODE PARAMETER
#define PKREG_WISUN_LIFE_COUNT          0xC0
#define PKREG_WISUN_DEATH_COUNT         0xC1
#define PKREG_WISUN_SUBLIFE_COUNT       0xC2
#define PKREG_WISUN_SYSTEM_REBOOT_COUNT 0xC3
// ------------------------------------------------------------------------------
// NICT #MOD_190917


// =========================================================
// 0xB0 レジスタロード＆セーブ
#define PKREG_ENV_WRITE_NICT            0xB0
#define PKREG_ENV_CALLNICTDEF           0xB1
// =========================================================
// 0xFF DEBUG
#define PKREG_DEBUG_ACC_UART            0xFF
// =========================================================

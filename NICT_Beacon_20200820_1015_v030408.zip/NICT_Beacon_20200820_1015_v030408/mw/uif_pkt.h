/* =========================================================
 * uif_pkt.h
 *
 *  Created on: 2017/01/09
 *      Author: t.miki
 *
 *  Copyright (C) 2016 Telepower .inc
 * =========================================================*/

#ifndef APPLICATION_TASK_UIF_PKT_H_
#define APPLICATION_TASK_UIF_PKT_H_

// =========================================================

#define SUCCESS 0
#define FAILURE 1

// =========================================================
//
#define	UIF_SYNCCODE	0xf2
//#define	UIF_BUFUSELEN	(180)			//	バッファ使用長
#define	UIF_BUFUSELEN	(255)				//	バッファ使用長 TELECの規定によりセット

// =========================================================
//

//	UIFパケット
typedef struct __attribute__((__packed__)) tagPKBASEHED {
	uint8_t		pklen;		// Packet length
	uint8_t		comtype;	// コマンドID
	uint8_t		sum;		// sum
	uint8_t		pktid;		// パケットID
//	uint8_t     buf[0];     // buf pointer
}PKBASEHED;

#define	PKBASEHED_SZ	sizeof(PKBASEHED)
#define	UIF_BUFLEN		(PKBASEHED_SZ+UIF_BUFUSELEN)	//	バッファ最大長

//  UIF-SENDパケット
typedef struct  __attribute__((__packed__)) tagPKBASESENDHED {
    uint8_t     stx;        // Packet STX
    PKBASEHED   pkt_hdr;
}PKBASESENDHED;

// =========================================================
//	コマンドIDの一覧

#define	PKCOM_REGPUT	0x70
#define	PKCOM_REGGET	0x67
#define	PKCOM_DSHORT	0x53
#define	PKCOM_DLONG		0x4c
#define	PKCOM_NACK		0x15
#define	PKCOM_ACK		0x06
#define	PKCOM_DISABLE	0x44
#define	PKCOM_ENABLE	0x45

#define PKCOM_BEACON    0x42


// =========================================================
//	機能ブロック
//	将来の機能拡張もこの形式により増設される
typedef	struct	__attribute__((__packed__))	tagPK_CONTAINER	{
	uint8_t	len;	//	長さ
	uint8_t	type;	//	プロトコルタイプ
}	PK_CONTAINER;

#define	REG_BYTE	        0x81
#define	REG_WORD	        0x82
#define	REG_DWORD	        0x84
#define	REG_DATA_MAX	    0x30
#define	REG_ATB_DATA(atb)	((atb)&(0x80))
#define	REG_ATB_SIZE(atb)	((atb)&(0x7f))

// =========================================================
//	レジスタ読み書き部
//
typedef	struct	__attribute__((__packed__))	tagREGLINK	{	//	無線部に乗せるデータか？
	uint8_t	regno;
	uint8_t	regtype;
	uint8_t	value[0];
}	REGLINK;

#define	REGLINK_SZ	sizeof(REGLINK)
#define	PLTMARK_REPEAT	02
#define	PLTMARK_ORG		01

// =========================================================
//	基本リンク部分
//
typedef	struct	__attribute__((__packed__))	tagBASELINK	{
	uint8_t	len;
	uint8_t	plot;
	uint8_t	destid;
	uint8_t	srceid;
}	BASELINK;

// =========================================================
//
#define	ERR_COM_NONSUPPORT	1
#define	ERR_NONMEMMORY		2
#define EVENT_QUETOFRONT_MASK   (0x80)

// =========================================================
//
// ----- タスクコマンド定義
typedef enum {
    CCSND_CMD_NONE = 0,         // 無効
    CCSND_CMD_INIT,             // 初期化

    CCSND_CMD_SEND_DATA,        // データ送信
    CCSND_CMD_SEND_ACK,         // ACK送信

    CCSND_CMD_SENDING_DATA_TU,  // データ送信待ちタイマ タイムアップ
    CCSND_CMD_SENDING_ACK_TU,   // ACK送信待ちタイマ タイムアップ
    CCSND_CMD_CS_OVER_TU,       // キャリアセンスオーバータイマ タイムアップ
    CCSND_CMD_SEND_OVER_TU,     // 送信完了オーバータイマ タイムアップ

    CCSND_CMD_FINISH_SEND,      // 送信完了確認
    CCSND_CMD_SET_LOGICALCH,    // チャンネル設定
    CCSND_CMD_SET_RFPOWER,      // 出力設定
    CCSND_CMD_SET_RFPOWERMAX,   // 出力設定
    CCSND_CMD_SET_CSTIME,       // キャリアセンス時間設定 : 0でキャリアセンス無効
    CCSND_CMD_SET_CSTIMEOUT,    // キャリアセンス時間タイムアウト設定
    CCSND_CMD_SET_COLLTIME,     // 衝突防止時間設定
    CCSND_CMD_SET_SNDTIMEOUT,   // 送信完了時間タイムアウト設定
    CCSND_CMD_SET_CS_THR,       // CSスレッショルド設定
    CCSND_CMD_MODE_SD_MW,       // 送信変調波形
    CCSND_CMD_MODE_SD_CW,       // 送信無変調波形
    CCSND_CMD_MODE_RX,          // 連続波形出力から抜ける
    CCSND_CMD_MODE_RECV,        // 受信モード送信完了時間タイムアウト設定

    CCSND_CMD_MODE_IDL,         // アイドルモードへ移行
    CCSND_CMD_MODE_SLEEP,       // SLEEPモードへ移行
    CCSND_CMD_MODE_AIR,         // 空中線モード
    CCSND_CMD_MODE_FRQOFF,      // 周波数偏差をセット

    CCSND_CMD_SEND_ACK_F = EVENT_QUETOFRONT_MASK    // ACK送信

} eCcSndSeqCommand;

// =========================================================
// 送信結果
#define CCSND_RESULT_SEND_OK    (0) // 送信完了
#define CCSND_RESULT_SEND_NG    (1) // 送信失敗
#define CCSND_RESULT_NO_CMD     (1) // コマンド無

// =========================================================
//
#if 0
typedef struct  tagUIF_U2L_INFO{
    struct  tagUIF_INFO *uif_info;
//    xTaskHandle     taskHandle;       // 生成タスク取得ハンドル
//    xQueueHandle    quehandle;
//    portBASE_TYPE   (*reciveFunc)();    // 応答メッセージイベント発行関数
    uint8_t  line[UIF_BUFUSELEN];
    uint8_t  getlen;
    uint8_t  rdp;
}   UIF_U2L_INFO;

typedef struct  tagUIF_L2U_INFO{
    struct  tagUIF_INFO *uif_info;
//    xTaskHandle     taskHandle;         // 生成タスク取得ハンドル
//    xQueueHandle    quehandle;
}   UIF_L2U_INFO;

typedef struct  tagUIF_INFO{
    UIF_U2L_INFO    *u2l_info;
    UIF_L2U_INFO    *l2u_info;
    //    xComPortHandle  pxPort;
    //    CB_PARAM        cb_param;
} UIF_INFO;
#endif

// ----- メッセージキューパケット構造体
 typedef struct __attribute__((__packed__)) {
        uint8_t         command;        // 応答コマンドメッセージ
        uint8_t         result;         // 応答結果
        void            *param;         //  パラメータ用のポインタ
        uint8_t         id;             // メッセージIDユニーク値　20130915
        uint8_t         length;         // 有効データ長
        uint8_t         data[1];        // 添付データ : 可変長配列として利用

        //  portBASE_TYPE   (*writeMsg)();  // 応答メッセージイベント発行関数
        //  xQueueHandle    returnQue;      // 戻しキュー
} msgAttachDataOld_t;

// =========================================================
// BLE Format
typedef struct tagUIF_BLE
{
//    uint8_t     mac_address ;
    uint16_t    hdr ;
    uint8_t     payload[37] ;
} msgBleData_t;

// =========================================================
//
#define MAC_HDRIE_TRM  0x3f00
#define MAC_PLDIE_TRM  0xf800

typedef struct __attribute__((__packed__))  _api_Machdr_s
{
    struct {
        uint8_t bFrameType:3;
        uint8_t bSecurityEnable:1;
        uint8_t bFramePending:1;
        uint8_t bAckRequest:1;
        uint8_t bPANIDCompress:1;
        uint8_t bReserved:1;
        uint8_t bSequenceNumberSuppression:1;
        uint8_t bIEListPresent:1;
        uint8_t bDistinationAddressingMode:2;
        uint8_t bFrameVersion:2;
        uint8_t bSourceAddressingMode:2;
    } FrameCtrl;
    uint8_t  SeqNum;
    uint16_t PANId;
    uint16_t DistAddress;
    uint64_t SrcAddress;
//    uint16_t HdrIE;
}Machdr_S_t ;

typedef struct _api_Machdr_l
{
    struct {
        uint8_t bFrameType:3;
        uint8_t bSecurityEnable:1;
        uint8_t bFramePending:1;
        uint8_t bAckRequest:1;
        uint8_t bPANIDCompress:1;
        uint8_t bReserved:1;
        uint8_t bSequenceNumberSuppression:1;
        uint8_t bIEListPresent:1;
        uint8_t bDistinationAddressingMode:2;
        uint8_t bFrameVersion:2;
        uint8_t bSourceAddressingMode:2;
    } FrameCtrl;
    uint8_t  SeqNum;
    uint16_t PANId;
    uint64_t DistAddress;
    uint64_t SrcAddress;
//    uint16_t HdrIE;
}Machdr_L_t ;

typedef struct __attribute__((__packed__))  _api_MacPay
{
    struct {
        uint16_t PeyloadIElen :10;
        uint16_t GroupID :4;
        uint16_t Type :1;
    } Descriptor;
    uint8_t  VenderOUI[3];
//    uint8_t  CtrlBsData[20];
//    uint8_t  CtrlBsOpt[12];
//    uint16_t TermCode;
    uint8_t  Payload[225];
}MacPay_t ;

typedef struct tagUIF_WiSUN
{
    Machdr_S_t mac_h ;
    uint8_t  MacPayload[230];

//    MacPay_t mac_p ;
//    uint16_t FCS;
} msgWiSUNAttachData_t;

// =========================================================
// beacon header length
typedef struct __attribute__((__packed__))  tagProtocol_t
{
    uint8_t         protocol_hdr_len ;      // プロトコルヘッダ長　  :3
    uint8_t         protocol_Hdr ;          // プロトコルヘッダ種別 :2
    uint8_t         beacon_type ;           // Beacon属性
    uint8_t         attatch_len ;           // データ長
} msgProtocol_t ;

// =========================================================
// struct Ble Beacon data
//

typedef struct __attribute__((__packed__))  tagBleAttachData_t
{
    uint8_t         stx ;
    PKBASEHED       pkt_hdr ;
    msgProtocol_t   ptl_hdr ;
    msgBleData_t    ble ;
} msgBleAttachData_t ;

// =========================================================
// struct Wisun Beacon data
//

typedef struct __attribute__((__packed__))  tagWisunAttachData_t
{
    uint8_t         stx ;
    PKBASEHED       pkt_hdr ;
    msgProtocol_t   ptl_hdr ;
    msgWiSUNAttachData_t    wisun ;
} msgWisunAttachData_t ;

typedef struct __attribute__((__packed__))  tagAttachData_t
{
    PKBASEHED       pkt_hdr ;
    msgProtocol_t   ptl_hdr ;
    char            data[255] ;
} msgAttachData_t ;

// =========================================================
//
#define PTLBASEHED_SZ    sizeof(msgProtocol_t)
// =========================================================
//
int getSenser();
int pkt_sum(PKBASEHED*pkt);

// =========================================================
//

#endif /* APPLICATION_TASK_UIF_PKT_H_ */

// =========================================================
// - end of file
// =========================================================

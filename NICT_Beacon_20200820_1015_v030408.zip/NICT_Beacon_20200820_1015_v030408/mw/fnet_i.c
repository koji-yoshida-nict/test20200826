/* ========================================================
//
//	L1(RF MODULE)->UIF(UART)
//	モジュール
//
 * ======================================================== */
//
#include "DataClass/tp_stddef.h"
// =========================================================
#ifdef USE_FREERTOS

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#else
// =========================================================
// tirtos
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Queue.h>

#endif

#include "DataClass/container.h"

#include "application/TaskEvent.h"
#include "application/TaskError.h"
#include "application/Taskinit.h"
#include "env.h"
// =========================================================
//
#include "uif_pkt.h"
#include "fnet_i.h"
#include "reg.h"

/////////////////////////////////////////////////////////////////////////////////////////////
//	
//
/////////////////////////////////////////////////////////////////////////////////////////////
uint32_t err_syscnt	= 0;        // システムエラーカウント
uint32_t rcv_alloc_count = 0;
uint32_t rcv_free_count1 = 0;
uint32_t rcv_free_count2 = 0;

static unsigned char sendBuffer[270];

extern void putUartStr(unsigned char *p ,int length);
extern int getUartStr(unsigned char *p ,int size);

#if 0
STATI_COUNT stcount =
{
    .sendtotal  = 0,    // 送信総数
    .senderr    = 0,    // 送信エラー数
    .recvown    = 0,    // 自分宛て受信総数
    .recverr    = 0,    // 受信エラー数
    .recvair    = 0,    // 受信空中総数
    .slotsync   = 0,    // 同期数
    .relay      = 0     // リレーカウント
};
#endif

#if 0
LINK_COUNT lkcount = {
	.plink1	=	0,	//	受信物理LINK1
	.dlink1	=	0,	//	受信データLINK1
	.plink2	=	0,	//	受信物理LINK2
	.dlink2	=	0,	//	受信データLINK2
	};
#endif

#if	1

// =========================================================
//
// function : uint8_t uif_sendbBlebeacon()
//
uint8_t uif_sendBlebeacon(msgBleAttachData_t *Blepkt,  uint8_t pkid)
{
    int data_len = Blepkt->ptl_hdr.attatch_len ;
    int length = 0 ;
    PKBASEHED *pkt = (PKBASEHED *)&(Blepkt->pkt_hdr) ;

    Blepkt->stx     = UIF_SYNCCODE ;
    pkt->pklen      = length = PKBASEHED_SZ + PTLBASEHED_SZ + data_len ;
    pkt->comtype    = PKCOM_BEACON;  //
    pkt->sum        = 0;          //
    pkt->pktid      = pkid;       //
    pkt->sum        = pkt_sum(pkt);

#ifdef LOC_DEB
    putUsbStr((unsigned char*)Blepkt, length+1);

#else
    putUartStr((unsigned char*)Blepkt, length+1);
#endif
    return  length;
}

// =========================================================
//
// function : uint8_t uif_sendbWisunbeacon()
//
uint8_t uif_sendWisunbeacon(msgWisunAttachData_t *wisunpkt,  uint8_t pkid)
{
    int data_len = wisunpkt->ptl_hdr.attatch_len ;
    int length = 0 ;
    PKBASEHED *pkt = (PKBASEHED *)&(wisunpkt->pkt_hdr) ;

    wisunpkt->stx   =   UIF_SYNCCODE ;
    pkt->pklen      =   length = PKBASEHED_SZ + PTLBASEHED_SZ + data_len ;
    pkt->comtype    =   PKCOM_BEACON;  //
    pkt->sum        =   0;          //
    pkt->pktid      =   pkid;       //
    pkt->sum        =   pkt_sum(pkt);

#ifdef LOC_DEB
    putUsbStr((unsigned char*)wisunpkt, length+1);

#else
    putUartStr((unsigned char*)wisunpkt, length+1);
#endif

    return length;
}
// =========================================================
//
// function : uint8_t uif_sendack()
//	
uint8_t uif_sendack(PKBASEHED *pkt,	uint8_t	pkid)
{
    PKBASESENDHED *spkt;
    uint16_t length = 0 ;

    spkt = &sendBuffer;
    pkt = &(spkt->pkt_hdr);
    spkt->stx       =   UIF_SYNCCODE;

    pkt->pklen      = length = PKBASEHED_SZ;
    pkt->comtype    = PKCOM_ACK;
    pkt->sum        = 0;
    pkt->pktid      = pkid;
    pkt->sum        = pkt_sum(pkt);

//  putUartStr((unsigned char*)spkt, length+1);
    putUartStr((unsigned char*)sendBuffer, length+1);

	return	PKBASEHED_SZ;
}

// =========================================================
//
// function : uint8_t uif_sendnack()
//	
uint8_t uif_sendnack(PKBASEHED *pkt,uint8_t	pkid,uint8_t errlen,uint8_t	*errdat)
{
    PKBASESENDHED *spkt;
    uint16_t length = 0;

    spkt = &sendBuffer;
    pkt = &(spkt->pkt_hdr);
    spkt->stx = UIF_SYNCCODE;

    pkt->pklen      = length = PKBASEHED_SZ+errlen;
    pkt->comtype    = PKCOM_NACK;
    pkt->sum        = 0;
    pkt->pktid      = pkid;
    pkt->sum        = pkt_sum(pkt);

//  if(errlen)
//      memcpy((uint8_t*)(pkt+1), errdat,errlen);

//  putUartStr((unsigned char*)spkt, length+1);
    putUartStr((unsigned char*)sendBuffer, length+1);

    return	pkt->pklen;
}

// =========================================================
//
// function : uint8_t uif_sendregput()
//
uint8_t	uif_sendregput(PKBASEHED *pkt,uint8_t pkid,uint8_t datalen,uint8_t *dat)
{
//    PKBASESENDHED *spkt;
//    uint16_t length = 0 ;

    pkt->pklen      = PKBASEHED_SZ+datalen;
    pkt->comtype    = PKCOM_REGPUT;
    pkt->sum        = 0;
    pkt->pktid      = pkid;
    memcpy((uint8_t*)(pkt+1),dat ,datalen);
    pkt->sum        = pkt_sum(pkt);
    return pkt->pklen;
}
#endif

// =========================================================
// 共有メモリをアタッチをベースに解放する。
//
static uif_attachfree(msgAttachData_t *attach)
{
	COMBUFP	bufp;
	//	
//	bufp = (COMBUFP*)((uint8_t*)attach - COMBUFHED_SIZ);
	bufp = CARRYP2COMBUF(attach);

	combuf_free_block(bufp);
}

// =========================================================
//
//
void uif_sendresponce(PKBASEHED *pkt, uint8_t pkid, uint8_t datalen, uint8_t *dat)
{
    PKBASESENDHED *spkt;
    uint16_t length = 0 ;

    spkt = &sendBuffer;
    pkt = &(spkt->pkt_hdr);
    spkt->stx       =   UIF_SYNCCODE;

    pkt->pklen      =   length = PKBASEHED_SZ + REGLINK_SZ + datalen;
    pkt->comtype    =   PKCOM_REGPUT; //
    pkt->sum        =   0;
    pkt->pktid      =   pkid;       //
    memcpy((uint8_t*)(pkt+1),dat ,REGLINK_SZ + datalen);
    pkt->sum        =   pkt_sum(pkt);

    putUartStr((unsigned char*)sendBuffer, length+1);

//    return  pkt->pklen;
    return;
}
//////////////////////////////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////////////////////////////
// =========================================================
// - end of file
// =========================================================

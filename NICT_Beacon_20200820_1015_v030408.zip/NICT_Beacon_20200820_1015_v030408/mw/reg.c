/* =========================================================
 * reg.c
 *
 *  Created on: 2017/01/30
 *      Author: t.miki
 *
 *  Copyright (C) 2016 Telepower .inc
 * =========================================================*/
//
#include "DataClass/tp_stddef.h"
// =========================================================
#ifdef USE_FREERTOS

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "timers.h"
#include "semphr.h"
#else
// =========================================================
// tirtos
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Queue.h>

#endif
#include "uif_pkt.h"
#include "reg.h"
#include "regcmd.h"
#include "env.h"
#include "fnet_i.h"
//#include "slotlink.h"

#include "application/app_version.h"
#include "application/TaskEvent.h"
#include "application/TaskError.h"
#include "application/Taskinit.h"

static int reg_get(REG_MEM *regmem, PKBASEHED *pMsgQue);
static int reg_put(REG_MEM *regmem, PKBASEHED *pMsgQue);
static int reg_nop(REG_MEM *regmem, PKBASEHED *pMsgQue);

static int com_environ_write_nict(REG_MEM *regmem, PKBASEHED *pMsgQue);
static int com_environ_call_nict(REG_MEM *regmem, PKBASEHED *pMsgQue);

const uint8_t   ver[]       = VERSION;

uint8_t         dmybyte     = 0xab;
uint16_t        dmyword     = 0xabcd;
uint32_t        dmydword    = 0x1234abcd;
uint8_t         dmydata[]   = "testdata";

const
REG_MEM reg_tbl[] =
{
{PKREG_RF_VER,                  sizeof(ver),    (void *)ver,                            0, 0, 0, reg_get, reg_nop},
// ===================================================================================================================
{PKREG_WISUN_CH1,               REG_BYTE,       &env_nictparam.wiSunCh1,                0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_CH2,               REG_BYTE,       &env_nictparam.wiSunCh2,                0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_CH3,               REG_BYTE,       &env_nictparam.wiSunCh3,                0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_BURST_CH,          REG_BYTE,       &env_nictparam.burstCh,                 0, 0, 0, reg_get, reg_put},
// ===================================================================================================================
{PKREG_DEVICE_RUNMODE,          REG_BYTE,       &env_nictparam.deviceRunmode,           0, 0, 0, reg_get, reg_put},
{PKREG_BEACONMODE_EXIST,        REG_BYTE,       &env_nictparam.beaconExist,             0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_EXIST,             REG_BYTE,       &env_nictparam.WiSUNBaseBeaconEn,       0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PERIOD,            REG_WORD,       &env_nictparam.WiSUNBaseInterval,       0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_INTERVAL,          REG_BYTE,       &env_nictparam.WiSUNBurstPeriod,        0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_BURST_COUNT,       REG_BYTE,       &env_nictparam.WiSUNBurstCount,         0, 0, 0, reg_get, reg_put},
{PKREG_BLE_EXIST,               REG_BYTE,       &env_nictparam.bleBaseBeaconEn,         0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PERIOD,              REG_WORD,       &env_nictparam.bleBaseInterval,         0, 0, 0, reg_get, reg_put},
{PKREG_BLE_BURST_INTERVAL,      REG_BYTE,       &env_nictparam.bleBurstPeriod,          0, 0, 0, reg_get, reg_put},
{PKREG_BLE_BURST_COUNT,         REG_BYTE,       &env_nictparam.bleBurstCount,           0, 0, 0, reg_get, reg_put},
// ===================================================================================================================
{PKREG_PACKET_WISUN_EXISTS,     EXIST_LEN,      &env_nictparam.WiSUNExist,              0, 0, 0, reg_get, reg_put},
{PKREG_PACKET_BLE_EXISTS,       EXIST_LEN,      &env_nictparam.bleExist,                0, 0, 0, reg_get, reg_put},
{PKREG_PACKET_VENDOR_1,         REG_BYTE,       &env_nictparam.vendor1,                 0, 0, 0, reg_get, reg_put},
{PKREG_PACKET_VENDOR_2,         REG_BYTE,       &env_nictparam.vendor2,                 0, 0, 0, reg_get, reg_put},
{PKREG_PACKET_VENDOR_3,         REG_BYTE,       &env_nictparam.vendor3,                 0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_PANID_DEF, REG_WORD,       &env_nictparam.WiSUNPayloadPanidNormal, 0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_PANID_WALK,REG_WORD,       &env_nictparam.WiSUNPayloadPanidWalk,   0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_PANID_RUN, REG_WORD,       &env_nictparam.WiSUNPayloadPanidRun,    0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_PANID_DEF,   REG_WORD,       &env_nictparam.blePayloadPanidNormal,   0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_PANID_WALK,  REG_WORD,       &env_nictparam.blePayloadPanidWalk,     0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_PANID_RUN,   REG_WORD,       &env_nictparam.blePayloadPanidRun,      0, 0, 0, reg_get, reg_put},
// ===================================================================================================================
{PKREG_WISUN_PAYLOAD_PANID,     REG_WORD,       &env_nictparam.WiSUNPayloadPanid,       0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_NAME,      LOCALNAME_LEN,  &env_nictparam.WiSUNPayloadName,        0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_FLAG,      REG_WORD,       &env_nictparam.WiSUNPayloadFlag,        0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_HOP,       REG_BYTE,       &env_nictparam.WiSUNPayloadHop,         0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_SEQUENCE,  REG_WORD,       &env_nictparam.WiSUNPayloadSequence,    0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_REPIOD,    REG_WORD,       &env_nictparam.WiSUNPayloadPepiod,      0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_SENDID,    WS_SENDID_LEN,  &env_nictparam.WiSUNPayloadSendid,      0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_SERVID,    REG_BYTE,       &env_nictparam.WiSUNPayloadServid,      0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_DESTID,    WS_DESTID_LEN,  &env_nictparam.WiSUNPayloadDestid,      0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_HOP_MAX,   REG_BYTE,       &env_nictparam.WiSUNPayloadHopmax,      0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_DISTANCE,  REG_WORD,       &env_nictparam.WiSUNPayloadDistance,    0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_TIME,      TIME_LEN,       &env_nictparam.WiSUNPayloadTime,        0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_PAYLOAD_VOLTAGE,   REG_BYTE,       0,                                      0, 0, 0, reg_nop, reg_nop},
{PKREG_WISUN_PAYLOAD_ACTSTAT,   REG_BYTE,       0,                                      0, 0, 0, reg_nop, reg_nop},
{PKREG_WISUN_PAYLOAD_ACCDATA,   REG_BYTE,       0,                                      0, 0, 0, reg_nop, reg_nop},
// ===================================================================================================================
{PKREG_BLE_PAYLOAD_PANID,       REG_WORD,       &env_nictparam.blePayloadPanid,         0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_NAME,        LOCALNAME_LEN,  &env_nictparam.blePayloadName,          0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_FLAG,        REG_WORD,       &env_nictparam.blePayloadFlag,          0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_HOP,         REG_BYTE,       &env_nictparam.blePayloadHop,           0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_SEQUENCE,    REG_WORD,       &env_nictparam.blePayloadSequence,      0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_REPIOD,      REG_WORD,       &env_nictparam.blePayloadPepiod,        0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_SENDID,      BLE_SENDID_LEN, &env_nictparam.blePayloadSendid,        0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_SERVID,      REG_BYTE,       &env_nictparam.blePayloadServid,        0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_DESTID,      BLE_DESTID_LEN, &env_nictparam.blePayloadDestid,        0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_HOP_MAX,     REG_BYTE,       &env_nictparam.blePayloadHopmax,        0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_DISTANCE,    REG_WORD,       &env_nictparam.blePayloadDistance,      0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_TIME,        TIME_LEN,       &env_nictparam.blePayloadTime,          0, 0, 0, reg_get, reg_put},
{PKREG_BLE_PAYLOAD_VOLTAGE,     REG_BYTE,       0,                                      0, 0, 0, reg_nop, reg_nop},
{PKREG_BLE_PAYLOAD_ACTSTAT,     REG_BYTE,       0,                                      0, 0, 0, reg_nop, reg_nop},
{PKREG_BLE_PAYLOAD_ACCDATA,     REG_BYTE,       0,                                      0, 0, 0, reg_nop, reg_nop},
// ===================================================================================================================
{PKREG_ACC_DYNAMIC_RANGE,       REG_BYTE,       &env_nictparam.accDynamicRange,         0, 0, 0, reg_get, reg_put},
{PKREG_ACC_SAMPRING_PERIOD,     REG_BYTE,       &env_nictparam.accSampringPeriod,       0, 0, 0, reg_get, reg_put},
// ===================================================================================================================
{PKREG_ACTIVE_WINDOW_DATA,      REG_BYTE,       &env_nictparam.activeWindowData,        0, 0, 0, reg_get, reg_put},
{PKREG_ACTIVE_WINDOW_NUMBER,    REG_BYTE,       &env_nictparam.activeWindowNumber,      0, 0, 0, reg_get, reg_put},
// ===================================================================================================================
{PKREG_SLEEP_WAKEUP_VALUE,      REG_BYTE,       &env_nictparam.sleepWakeupValue,        0, 0, 0, reg_get, reg_put},
{PKREG_SLEEP_JUDGE_VALUE,       REG_BYTE,       &env_nictparam.sleepJudgeValue,         0, 0, 0, reg_get, reg_put},
{PKREG_SLEEP_JUDGE_NUMBER,      REG_BYTE,       &env_nictparam.sleepJudgeNumber,        0, 0, 0, reg_get, reg_put},
// ===================================================================================================================
{PKREG_WALK_JUDGE_VALUE,        REG_BYTE,       &env_nictparam.walkJudgeValue,          0, 0, 0, reg_get, reg_put},
{PKREG_WALK_JUDGE_NUMBER,       REG_BYTE,       &env_nictparam.walkJudgeNumber,         0, 0, 0, reg_get, reg_put},
{PKREG_WALK_INTERVAL,           REG_WORD,       &env_nictparam.walkWisunInterval,       0, 0, 0, reg_get, reg_put},
{PKREG_WALK_WISUN_BURST_PERIOD, REG_BYTE,       &env_nictparam.walkWisunBurstPeriod,    0, 0, 0, reg_get, reg_put},
{PKREG_WALK_WISUN_BURST_COUNT,  REG_BYTE,       &env_nictparam.walkWisunBurstCount,     0, 0, 0, reg_get, reg_put},
{PKREG_WALK_BLE_INTERVAL,       REG_WORD,       &env_nictparam.walkBleInterval,         0, 0, 0, reg_get, reg_put},
{PKREG_WALK_BLE_BURST_PERIOD,   REG_BYTE,       &env_nictparam.walkBleBurstPeriod,      0, 0, 0, reg_get, reg_put},
{PKREG_WALK_BLE_BURST_COUNT,    REG_BYTE,       &env_nictparam.walkBleBurstCount,       0, 0, 0, reg_get, reg_put},
// ===================================================================================================================
{PKREG_RUN_JUDGE_VALUE,         REG_BYTE,       &env_nictparam.runJudgeValue,           0, 0, 0, reg_get, reg_put},
{PKREG_RUN_JUDGE_NUMBER,        REG_BYTE,       &env_nictparam.runJudgeNumber,          0, 0, 0, reg_get, reg_put},
{PKREG_RUN_WISUN_INTERVAL,      REG_WORD,       &env_nictparam.runWisunInterval,        0, 0, 0, reg_get, reg_put},
{PKREG_RUN_WISUN_BURST_PERIOD,  REG_BYTE,       &env_nictparam.runWisunBurstPeriod,     0, 0, 0, reg_get, reg_put},
{PKREG_RUN_WISUN_BURST_COUNT,   REG_BYTE,       &env_nictparam.runWisunBurstCount,      0, 0, 0, reg_get, reg_put},
{PKREG_RUN_BLE_INTERVAL,        REG_WORD,       &env_nictparam.runBleInterval,          0, 0, 0, reg_get, reg_put},
{PKREG_RUN_BLE_BURST_PERIOD,    REG_BYTE,       &env_nictparam.runBleBurstPeriod,       0, 0, 0, reg_get, reg_put},
{PKREG_RUN_BLE_BURST_COUNT,     REG_BYTE,       &env_nictparam.runBleBurstCount,        0, 0, 0, reg_get, reg_put},
// ------------------------------------------------------------------------------
// NICT #MOD_190917
{PKREG_WISUN_LIFE_COUNT,       REG_WORD,        &env_nictparam.WiSUNLifeCount,          0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_DEATH_COUNT,      REG_WORD,        &env_nictparam.WiSUNDeathCount,         0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_SUBLIFE_COUNT,    REG_WORD,        &env_nictparam.WiSUNSublifeCount,         0, 0, 0, reg_get, reg_put},
{PKREG_WISUN_SYSTEM_REBOOT_COUNT,    REG_WORD,        &env_nictparam.WiSUNSystemRebootCount,         0, 0, 0, reg_get, reg_put},
// ===================================================================================================================
{PKREG_ENV_WRITE_NICT,          REG_BYTE,       0,                                      0, 0, 0, reg_nop, com_environ_write_nict},
{PKREG_ENV_CALLNICTDEF,         REG_BYTE,       0,                                      0, 0, 0, reg_nop, com_environ_call_nict},
// ===================================================================================================================
{PKREG_DEBUG_ACC_UART,          REG_BYTE,       &g_Debug_Flag,                          0, 0, 0, reg_get, reg_put},
// ===================================================================================================================
};
REG_MEM reg_tbl_InRam;

// =========================================================
//
//
const REG_MEM *tbl_search(uint8_t regno)
{
    int i;
    int tblmax;

    tblmax = (sizeof(reg_tbl) / sizeof(REG_MEM));

    for (i = 0; i < tblmax; i++)
    {
        if (reg_tbl[i].regno == regno)
        {
            return &reg_tbl[i];
        }
    }
    return NULL;
}

// =========================================================
//
//    REGISTER GET　処理
//
static int reg_get(REG_MEM *regmem, PKBASEHED *pMsgQue)
{
    PKBASEHED *pkthed;
    REGLINK *reglink;
    int len;
    uint8_t regtype;

    pkthed = (PKBASEHED*)pMsgQue;
    reglink = (REGLINK*)(pkthed+1);

    //
    if(REG_ATB_DATA(regmem->regatb))    //    数値属性の時
    {
        if(reglink->regtype != 0)
        {
            len = pkthed->pklen - (REGLINK_SZ + PKBASEHED_SZ);
            if (/*(REG_ATB_SIZE(reglink->regtype) != len) ||*/
                    (reglink->regtype != regmem->regatb))
            {
                uif_sendnack(pkthed, pkthed->pktid, 0, 0);
                return SUCCESS;
            }
            regtype = regmem->regatb;
        }
        else    // ==0の時
        {
            regtype = regmem->regatb;
            reglink->regtype = regtype;//    20131204
        }
    }
    else
    {
        if(REG_ATB_DATA(reglink->regtype))  // 数値属性の時
        {
            uif_sendnack(pkthed, pkthed->pktid, 0, 0);
            return SUCCESS;
        }
        else
        {
            if(reglink->regtype == 0)
            {
                reglink->regtype = regtype = regmem->regatb;
            }
            else
            {
                if(reglink->regtype < regmem->regatb)
                    regtype = reglink->regtype;
                else
                {
                    reglink->regtype = regtype = regmem->regatb;
                }
                //
                if(regtype > REG_DATA_MAX)
                    regtype = REG_DATA_MAX;
            }
        }
    }

    switch(regtype)
    {
    case REG_BYTE:
        *(uint8_t*)reglink->value = *(uint8_t*)regmem->data;    //
        len = 1;
        break;
    case REG_WORD:
        *(uint16_t*)reglink->value = *(uint16_t*)regmem->data;    //
        len = 2;
        break;
    case REG_DWORD:
        *(uint32_t*)reglink->value = *(uint32_t*)regmem->data;    //
        len = 4;
        break;
    default:
        len = regtype;
        memcpy(reglink->value,regmem->data,len);
    }

    uif_sendresponce(pkthed, pkthed->pktid, len, (uint8_t*)reglink);

    return SUCCESS;
}

// =========================================================
//
//    REGISTER PUT　処理
//
static int reg_put(REG_MEM *regmem, PKBASEHED *pMsgQue)
{
    PKBASEHED *pkthed;
    REGLINK *reglink;
    int len;
    uint8_t regtype;

    pkthed = (PKBASEHED*)pMsgQue;
    reglink = (REGLINK*)(pkthed+1);
    
    // 転送タイプregtypeを判定する。
    if(REG_ATB_DATA(regmem->regatb))    // 指定レジスタが、データ指定の時
    {
//      if(reglink->regtype != 0) {
            len = pkthed->pklen - (REGLINK_SZ + PKBASEHED_SZ);
            if((REG_ATB_SIZE(reglink->regtype) != len)
                    || (reglink->regtype != regmem->regatb))
            {   // 型が合わない時は、エラーとする。
                // まとめてNACK処理
                goto errexit;
//                return SUCCESS;
            }
//      }
        regtype = regmem->regatb;
    }
    else    // 文字列ブロック転送指定の場合
    {
        if(reglink->regtype == 0)   // 指定がない時は
        {
            goto errexit;
//            regtype = regmem->regatb;   // サイズは、テーブルから
        }
        else
        {//    小さいほうを採用する。
            if(reglink->regtype < regmem->regatb)
                regtype = reglink->regtype;
            else
                regtype = regmem->regatb;
            // データサイズの最大値の調整
            if(regtype > REG_DATA_MAX)
                regtype    = REG_DATA_MAX;
        }
    }
    // 値域チェック
    switch(reglink->regno)
    {
    case PKREG_WISUN_CH1:
    case PKREG_WISUN_CH2:
    case PKREG_WISUN_CH3:
    case PKREG_WISUN_BURST_CH:
        {
            int match = reglink->value[0];
            // 0xFF
            if(match == 0xFF)
            {
                break;
            }
            // 偶数
            if(match % 2 == 0)
            {
                goto errexit;
            }
            // lower 33
            if(match < 33)
            {
                goto errexit;
            }
            // upper 59
            if(match > 59)
            {
                goto errexit;
            }
        }
        break;
    case PKREG_WISUN_INTERVAL:
        {
            int match = reglink->value[0];
            if(match < 2)
            {
                goto errexit;
            }
            if(match > 100)
            {
                goto errexit;
            }
        }
        break;
    case PKREG_BLE_BURST_INTERVAL:
    {
        int match = reglink->value[0];
        if(match < 5)
        {
            goto errexit;
        }
        if(match > 100)
        {
            goto errexit;
        }
    }

        break;
    default :
        break;
    }

    // 実際にデータをセットする。
    switch(regtype) //決定された型で分岐
    {
    case REG_BYTE:
        *(uint8_t*)regmem->data = *(uint8_t*)reglink->value;    //
        len = 1;
        break;
    case REG_WORD:
        *(uint16_t*)regmem->data = *(uint16_t*)reglink->value;    //
        len = 2;
        break;
    case REG_DWORD:
        *(uint32_t*)regmem->data = *(uint32_t*)reglink->value;    //
        len = 4;
        break;
    default:
        len = regtype;
        memcpy(regmem->data,reglink->value,len);
    }

    uif_sendack(pkthed, pkthed->pktid);
    return SUCCESS;

errexit:
    uif_sendnack(pkthed,pkthed->pktid,0,0);

    return SUCCESS;
}

// =========================================================
//
//    何も作業しない場合。
//
static int reg_nop(REG_MEM *regmem, PKBASEHED *pMsgQue)
{
    PKBASEHED *pkthed;

    pkthed = (PKBASEHED*)pMsgQue;
    uif_sendnack(pkthed, pkthed->pktid, 0, 0);

    return SUCCESS;
}

// =========================================================
//
//
static int com_environ_write_nict(REG_MEM *regmem, PKBASEHED *pMsgQue)
{
    PKBASEHED *pkthed;
    REGLINK *reglink;

    pkthed = (PKBASEHED*)pMsgQue;
    reglink = (REGLINK*)(pkthed+1);

    if(reglink->regtype == REG_BYTE)
    {
        if(reglink->value[0] == 0x00)
        {
            environ_write_nict();
            uif_sendack(pkthed,pkthed->pktid);
            return SUCCESS;
        }
    }

    uif_sendnack(pkthed,pkthed->pktid, 0, 0);

    return SUCCESS;
}

// =========================================================
//
//
static int com_environ_call_nict(REG_MEM *regmem, PKBASEHED *pMsgQue)
{
    PKBASEHED *pkthed;
    REGLINK *reglink;
    pkthed = (PKBASEHED*)pMsgQue;
    reglink = (REGLINK*)(pkthed+1);

    if(reglink->regtype == REG_BYTE)
    {
        if(reglink->value[0] == 0x00)
        {
            environ_recall_nict();
            uif_sendack(pkthed,pkthed->pktid);
            return SUCCESS;
        }
    }

    uif_sendnack(pkthed,pkthed->pktid, 0, 0);

    return SUCCESS;
}

// =========================================================
// - end of file
// =========================================================

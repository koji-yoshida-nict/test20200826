/**
 *	@file	flash_write_inf.h
 *	@brief	Single-Byte Flash write.
 *			Flash(Information memory segment) B~D segments
 *
 *	@author	T.Kaneko
 *	@date	2011-12-12
 *Input parameters
 *	@param	int				seg_no  - 1 ~ 3 (B ~ D, 128byte unit)
 *	@param	unsigned char	*start_adr  - data source start address
 *	@param	long			leng  - data source copy size
 *Output parameters
 *	@return	void
 *
 */

#ifndef _FLASH_WRITE_INF_H_
#define _FLASH_WRITE_INF_H_

#define SECTOR_SIZE 4096               // 4KB

extern int flash_write(int seg_no, unsigned char *start_adr, long leng);
extern int flash_read(int seg_no, unsigned char *start_adr, long leng);

#endif /*_FLASH_WRITE_INF_H_*/

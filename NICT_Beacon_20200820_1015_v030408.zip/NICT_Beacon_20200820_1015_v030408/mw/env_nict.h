// =========================================================
//
//	アプリケーション用環境変数領域

#ifndef ENV_NICT_H
#define ENV_NICT_H

#include "DataClass/tp_stddef.h"
#include "application/app_version.h"
// =========================================================
// NICT Define
// NICT #MOD_190917
#define DEVICE_RUNMODE_EVENT      0x01  // 0x00:定期発信モード / 0x01:イベント発信モード
#define DEVICE_RUNMODE_TIMER      0x02  // 0x02:定期発信モード / 0x01:イベント発信モード  19/09/17

// #define BEACON_MODE_DISABLE       0x00  // Wi-SUN Beacon定期発信有効設定   0x0: 無効
//                                         // 定周期WISUN発信無効
// #define BEACON_MODE_INTERVAL      0x01  // Wi-SUN Beacon定期発信有効設定  0x01: Interval Timer Mode Beacon
//                                         // 定周期WISUN発信有効　100msec timer 1sec - 1 hour (0x0E10)
// #define BEACON_MODE_LIFE_COUNT    0x02  // Wi-SUN Beacon定期発信有効設定  0x02: Life Count Mode Beacon
//                                         // 定期間無発信イベント発信有効  1min 60 min - 24 hour 1440min (0x05a0)
#define BEACON_BLE_ENABLE         0x01
#define BEACON_WISUN_ENABLE       0x02

// =========================================================
#define SYNCMODE_MASTER 0
#define SYNCMODE_SLAVE  1

#define EXIST_LEN       2
#define LOCALNAME_LEN   8
#define BLE_ADDR_LEN    6
#define WISUN_ADDR_LEN  8

#define BLE_SENDID_LEN  6
#define BLE_DESTID_LEN  8
#define WS_SENDID_LEN   8
#define WS_DESTID_LEN   8
#define TIME_LEN        3

// =========================================================
//
//  アプリケーション用に不揮発性メモリに記録する。
typedef struct  __attribute__((__packed__)) tagENV_NICTPARAM
{
    uint8_t     wiSunCh1;           // WiSUN発信 Ch1  0xff 無効化
    uint8_t     wiSunCh2;           // WiSun発信 Ch2  0xff 無効化
    uint8_t     wiSunCh3;           // WiSun発信 Ch3  0xff 無効化
    uint8_t     burstCh;            // WiSunバーストCH
    // beacon mode
    uint8_t     deviceRunmode;      // 起動モード　(0x01:イベント発信モード, 0x02:定期発信モード, 0x03:ライフカウントモード)
    uint8_t     beaconExist;        // Beacon有効設定    0x01:BLE 0x02:WiSun 0x04:Wi-SUN Burst 0x08:BLE Burst
    // WiSUN 定期発信 mode
    uint8_t     WiSUNBaseBeaconEn;  // WiSunBeacon定期発信有効設定   0x0/0x01
    uint16_t    WiSUNBaseInterval;  // WiSUN定期発信間隔(100msec)

    uint8_t     WiSUNBurstPeriod;   // wisunバースト周期
    uint8_t     WiSUNBurstCount;    // wisunバースト回数
    uint8_t     bleBaseBeaconEn;    // BleBeacon有効設定    0x0/0x01
    uint16_t    bleBaseInterval;    // BLE定期発信間隔(100msec)
    uint8_t     bleBurstPeriod;     // bleバースト周期
    uint8_t     bleBurstCount;      // bleバースト回数
// ------------------------------------------------------------------------------
// NICT #MOD_190917
    uint16_t    WiSUNLifeCount;     // WiSUN定期発信Life Count (1min)
    uint16_t    WiSUNDeathCount;    // WiSUN定期発信Death Count (ライフカウント後にPANIDを変えていく周期)
    uint16_t    WiSUNSublifeCount;  // WiSUN Sub-Life Count （AppDataに乗せる各PANIDごとのさらなる異常度）
    uint16_t    WiSUNSystemRebootCount; // 何発WiSUN発信するごとにFWをリセットするか
  
    uint8_t     WiSUNExist[EXIST_LEN];
    uint8_t     bleExist[EXIST_LEN];
    uint8_t     vendor1;
    uint8_t     vendor2;
    uint8_t     vendor3;

    // 加速度パターン　WiSUN　送信時　PANID
    uint16_t    WiSUNPayloadPanidNormal;    // Wi-SUN PANID 通常モード
    uint16_t    WiSUNPayloadPanidWalk;      // Wi-SUN PANID （イベントモード 歩行）
                                            // 特別状態１　PANID　（タイマーモード　12時間無発信）
    uint16_t    WiSUNPayloadPanidRun;       // Wi-SUN PANID （イベントモード 走行）
                                            // 特別状態２　PANID　（タイマーモード　24時間無発信）
                                            //
    // 加速度パターン　BLE　送信時　PANID
    uint16_t    blePayloadPanidNormal;      // BLE PANID 通常モード
    uint16_t    blePayloadPanidWalk;        // BLE PANID イベントモード 歩行
                                            // 特別状態１　PANID　（タイマーモード　12時間無発信）
    uint16_t    blePayloadPanidRun;         // BLE PANID イベントモード 走行
                                            // 特別状態２　PANID　（タイマーモード　24時間無発信）

    uint16_t    WiSUNPayloadPanid;          //
    uint8_t     WiSUNPayloadName[LOCALNAME_LEN];
    uint16_t    WiSUNPayloadFlag;
    uint8_t     WiSUNPayloadHop;
    uint16_t    WiSUNPayloadSequence;
    uint16_t    WiSUNPayloadPepiod;
    uint8_t     WiSUNPayloadSendid[WS_SENDID_LEN];
    uint8_t     WiSUNPayloadServid;
    uint8_t     WiSUNPayloadDestid[WS_DESTID_LEN];
    uint8_t     WiSUNPayloadHopmax;
    uint16_t    WiSUNPayloadDistance;
    uint8_t     WiSUNPayloadTime[TIME_LEN];
    uint8_t     WiSUNPayloadVoltage;
    uint8_t     WiSUNPayloadActStat;
    uint8_t     WiSUNPayloadAccdata;

    uint16_t    blePayloadPanid;
    uint8_t     blePayloadName[LOCALNAME_LEN];
    uint16_t    blePayloadFlag;
    uint8_t     blePayloadHop;
    uint16_t    blePayloadSequence;
    uint16_t    blePayloadPepiod;
    uint8_t     blePayloadSendid[BLE_SENDID_LEN];
    uint8_t     blePayloadServid;
    uint8_t     blePayloadDestid[BLE_DESTID_LEN];
    uint8_t     blePayloadHopmax;
    uint16_t    blePayloadDistance;
    uint8_t     blePayloadTime[TIME_LEN];
    uint8_t     blePayloadVoltage;
    uint8_t     blePayloadActStat;
    uint8_t     blePayloadAccdata;

    uint8_t     accDynamicRange;    // 加速度センサ：ダイナミックレンジ
    uint8_t     accSampringPeriod;  // 加速度センサ：サンプリング周期

    uint8_t     activeWindowData;   // アクティブ（歩行走行）状態での計測窓幅（サンプリング周期＊activeWindowWidth=窓幅時間）
    uint8_t     activeWindowNumber; // アクティブ（歩行走行）状態での計測窓数

    uint8_t     sleepWakeupValue;   // SLEEPモード解除閾値（割り込み設定値）
    uint8_t     sleepJudgeValue;    // SLEEPモード判定強度(加速度センサ測定値のスカラー値と比較）
    uint8_t     sleepJudgeNumber;   // SLEEPモード判定数（判定強度を超える窓の数）

    uint8_t     walkJudgeValue;     // 歩行モード判定強度(加速度センサ測定値のスカラー値と比較）
    uint8_t     walkJudgeNumber;    // 歩行モード判定数（判定強度を超える窓の数）

    uint16_t    walkWisunInterval;  //
    uint8_t     walkWisunBurstPeriod;
    uint8_t     walkWisunBurstCount;

    uint16_t    walkBleInterval;
    uint8_t     walkBleBurstPeriod;
    uint8_t     walkBleBurstCount;

    uint8_t     runJudgeValue;      // 走行モード判定強度(加速度センサ測定値のスカラー値と比較）
    uint8_t     runJudgeNumber;     // 走行モード判定数（判定強度を超える窓の数）

    uint16_t    runWisunInterval;
    uint8_t     runWisunBurstPeriod;
    uint8_t     runWisunBurstCount;

    uint16_t    runBleInterval;
    uint8_t     runBleBurstPeriod;
    uint8_t     runBleBurstCount;

    uint8_t     preamble;           // プリアンブル  (15) byte
    uint32_t    syncword;           // Sync Word     (0x904e)

    uint8_t     bleAddress[BLE_ADDR_LEN];
    uint8_t     wiSunAddress[WISUN_ADDR_LEN];
    // =========================================================
    uint8_t     watermark;          //
} ENV_NICTPARAM;

#endif

// =========================================================
// - end of file
// =========================================================

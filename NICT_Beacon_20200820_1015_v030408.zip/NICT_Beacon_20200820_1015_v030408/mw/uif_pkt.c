/* =========================================================
 * uif_pkt.c
 *
 *  Created on: 2017/01/09
 *      Author: t.miki
 *
 *  Copyright (C) 2016 Telepower .inc
 * =========================================================*/

#include "stdint.h"
#include "string.h"

/////
#define ___TM 1

#include <xdc/std.h>
#include <xdc/runtime/IHeap.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Memory.h>
#include <xdc/runtime/Error.h>

///>>>

#include "at/platform/inc/AtTerm.h"

// Application #includes
#include "application/TaskEvent.h"
#include "application/TaskError.h"
#include "application/Taskinit.h"

// =========================================================
//
//#include "sl_gpio.h"
//#include "Debug.h"
//#include "UsbTask.h"

#include "DataClass/container.h"
#include "uif_pkt.h"
#include "reg.h"
#include "fnet_i.h"

// =========================================================
//
#ifndef USE_FREERTOS

//Semaphore_Struct semStruct;
//Semaphore_Handle msgQueus_sem;
//Queue_Handle msgQueue;
//Error_Block g_eb;

#endif
// =========================================================
//

#define _NO_UART_FUNC
#ifdef _NO_UART_FUNC

// =========================================================
//
#include "at/AtProcess.h"

// =========================================================
//
void putUartStr(unsigned char *p ,int length)
{
    int i ;

    for(i = 0; i < length; i++)
    {
        AtTerm_putChar(*p++);
//        AtTerm_putChar(p++);
    }
}

// =========================================================
//
int getUartStr(unsigned char *p ,int size)
{
    return AtTerm_getChar(p) ;
}

#else

extern void putUartStr(unsigned char *p ,int length);
extern int getUartStr(unsigned char *p ,int size);

#endif


// =========================================================
//#include <Drivers/BCUart.h>           // Include the backchannel UART "library"

//#define uifGetBufLen( ) UIF_BUFUSELEN
#define uifGetBufLen() CONTAINER_MESSAGE_LEN
static PKBASEHED *uif_getpkt(uint8_t* buf, int buflen);

/********************************************************************/

// =========================================================
// Task Param Initialize
// =========================================================
static Container_Handle cthu2lHandle=NULL;
static uint8_t U2lTask_init( void *pvParameters)            //
{
#define _MAX_ROW 4
    uint16_t length = sizeof(MessageObj) ;
    uint16_t maxRow = _MAX_ROW ;

// =========================================================
//
#ifdef USE_FREERTOS
    // =========================================================
    // Container Queue
    cthu2lHandle = Container_create(length , maxRow);

#else
#if 0
    /* setup clk1 to go off every 5 timer interrupts. */
    Error_init(&g_eb);
    // =========================================================
    // Container Semaphore
    Semaphore_construct(&semStruct, 0, NULL);
    msgQueus_sem = Semaphore_handle(&semStruct);
    // =========================================================
    // Create a Queue to hold the Clock Objects on
    msgQueue = Queue_create(NULL, &g_eb);
    if (msgQueue == NULL){
//        System_abort("Queue create failed");
    }
#endif
#endif
    return TRUE;
}

// =========================================================
// 名称:  Container情報取得
// 詳細:  本タスクのContainer情報を返す。
// 注意:
// =========================================================
Container_Handle getU2lTaskContainerInfo(void)
{
    return cthu2lHandle ;
}

// =========================================================
//
//  function : int uif_puts()
//
int uif_puts(ContainerObj_t pMsgQue )
{
#if 1
    unsigned char*str_ = pMsgQue->Msg.data ;
    int len = strlen((const char *)str_);
    putUartStr((unsigned char*)str_, len);
//    bcUart0Send(str, len);
#else
    int len = 0;
    while(*str) {
        xSerialPutChar( info->pxPort,   *str++, portMAX_DELAY);
        len ++;
        }
#endif
    return  len;
}

// =========================================================
//
//  function : int uif_putpkt()
//
int uif_putpkt(ContainerObj_t pMsgQue)
{
    int len;
    uint8_t  *bufp = (uint8_t*)pMsgQue->Msg.data;
    uint8_t  buf[2] = { UIF_SYNCCODE , 0 };

    len = pMsgQue->Msg.length;
#if 1
    putUartStr(buf, 1);
    putUartStr(bufp, len);

#else
    xSerialPutChar( info->pxPort,   UIF_SYNCCODE,   portMAX_DELAY);
    while(len--)
        xSerialPutChar( info->pxPort,   *bufp++,    portMAX_DELAY);
#endif
    return  len;
}

// =========================================================
//
//  function : int  pkt_sum()
//	パケットレイヤのSUM計算
//	SUM
//
int	pkt_sum(PKBASEHED*pkt)
{
	uint8_t*p =	(uint8_t*)pkt;
    uint8_t sum = 0;
	int	len	= pkt->pklen;

	while(len--)
		sum	-=	*p++;
	return	sum;
}

static uint32_t err_pktsum  =   0;
static uint32_t snd_alloc_count = 0;
//static uint32_t snd_free_count = 0;

// =========================================================
//
//  function :
//
static sft_memcpy(uint8_t*dp,uint8_t*sp, uint16_t len)
{
    while(len--)
        *dp++   =   *sp++;
}

#if 0
// =========================================================
//
//  function :
//  読み取り指定長さぶフラッシュする。
//
static void uif_flashlen(UIF_U2L_INFO *info, uint8_t  clrsz)
{
    if(info->getlen > clrsz) {
        uint8_t  cpysz;  //
        cpysz = info->getlen - clrsz;
        sft_memcpy(info->line, &info->line[clrsz],cpysz);
        info->getlen = cpysz;
        info->rdp = 0;
    }else{
        info->rdp = info->getlen = 0;
    }
}

// =========================================================
//
//  読み取りバッファをRPまでフラッシュする。
//
static void uif_flashrp(UIF_U2L_INFO *info)
{
    if(info->getlen > info->rdp){
        uint8_t  cpysz;  //  real copy size.
        cpysz = info->getlen - info->rdp;
        sft_memcpy(info->line, &info->line[info->rdp],cpysz);
        info->getlen = cpysz;
        info->rdp = 0;
    }else{
        info->rdp = info->getlen = 0;
    }
}

// =========================================================
//
//  function :
//
static int uif_rewind(UIF_U2L_INFO *info)
{
    info->rdp = 0;
    return 0;
}

//signed portBASE_TYPE dmyGetchar(int xport,uint8_t *getb, portTickType xBlockTime);
#endif
// =========================================================
//
//  function : static uint8_t uif_getbyte()
//
static uint8_t uif_getbyte(uint8_t *p)
{
#if 1
    uint8_t getb;

    getb = AtTerm_getChar((char *)p) ;

    return getb ;

/*
#define buf_size  64
    static int num = 0 ;
    static int len = 0 ;
    static char buf[buf_size] ;
    uint8_t getb;

    if(num==0){
        len = 0;
        num = getUartStr(buf,buf_size);
    }
    if(num){
        getb = buf[len];
        len ++ ;
        num -- ;
    }
    return getb ;
*/
#else
    int ret;
    uint8_t getb;

    //
    if(info->getlen <= info->rdp) {
///     ret = xSerialGetChar(info->uif_info->pxPort, &getb, portMAX_DELAY);
//      ret =  dmyGetchar( info->uif_info->pxPort, &getb,  portMAX_DELAY);
        if(ret == pdFALSE) {
            return  -1;
        }
        info->line[info->getlen++] = getb;
        info->rdp = info->getlen;
    }else{
        getb = info->line[info->rdp++];
    }

    return getb;
#endif
}

// =========================================================
//
//  function : static PKBASEHED *uif_getpkt()
//  パケット取得
//
#if 1
static PKBASEHED *uif_getpkt(uint8_t* buf, int buflen)
{
    int         ret ;
    uint8_t     getb;
    static char buff[CONTAINER_MESSAGE_LEN];
    PKBASEHED   *pkhed;
    uint8_t     len;
    uint8_t     sum;

    // =========================================================
    //
    enum    {                       //  get byte state code.
        SYNCGET,
        SIZEGET,
        DATAGET
    }   st= SYNCGET; //

    pkhed = (PKBASEHED*)buf;
//    pkhed = (PKBASEHED*)&info->line[0];
    while(1) {
        ret = uif_getbyte(&getb);   //  Get byte from UART
        if(ret!= 1) {             //  Check TIME UP
//          st= SYNCGET;            //  to Serch SYNC CODE Mode.
            continue;
        }
        if(len<=CONTAINER_MESSAGE_LEN){
            buff[len]=getb;
            len ++;
            sum +=  getb;               //  Clear Sumcounter.
        }else{
            st= SYNCGET;            //  to Serch SYNC CODE Mode.
            len = 0;
            sum = 0;
            continue;
        }
        switch(st) {
        case SYNCGET:
            // =========================================================
            //  同期コード
            if(UIF_SYNCCODE == getb) {
//                uif_flashrp(info);      //  同期コードまでは破棄
                st  = SIZEGET;
                len = 0;
                sum = 0;
            }else {                     //  バッファサイズをケア20130926
                if(len > UIF_BUFUSELEN/2) {   //  バッファが増えてきた
//                    uif_flashrp(info);  //  ここまでは不要なので破棄する。
                    len = 0;            //  同期取るまではバッファカウンタとして機能。
                }
            }
            break;
        case SIZEGET:
            // =========================================================
            //  Get Size
            pkhed->pklen = getb ;
            if  ((pkhed->pklen <  sizeof(PKBASEHED))  //  小さすぎるとき
             ||  (pkhed->pklen >= UIF_BUFUSELEN))     //  大きすぎるとき
                st = SYNCGET;           //  再度同期探索
            else
                st = DATAGET;
            break;
        case DATAGET:
            // =========================================================
            // Get All Data
            if(pkhed->pklen <= len)    {
                //  check packet length.
               if((sum) == 0){         //  Check SUM CODE
//               if(1){         //  Check SUM CODE
                    //  Success get command.
                    //  Copy commnad.
                    if (len < buflen)
                        buflen = len;
//                    memcpy(buf, pkhed,  buflen);
                    memcpy(buf, buff, buflen);
                    //  flash buffer
//                    uif_flashlen(info,  len);   //
                    st= SYNCGET;    //
                    return pkhed;  //  SUCCESS get data.
                }else {
                    err_pktsum  ++;
                    //  Sum error reget next synccode.
//                    uif_rewind(info);
                    // for debug
//                    memcpy(buff, pkhed,  len);
                    st= SYNCGET;    //
                }
            }
            break;
        default:                //  Err this state.
//            uif_flashrp(info);  //  Flash buffer
            st= SYNCGET;    //
        }
    }
    return (PKBASEHED*)NULL;
}


#else
static PKBASEHED *uif_getpkt(uint8_t* buf, int buflen)
{
    int ret ;
    uint8_t getb;
    static char buff[256];
    PKBASEHED   *pkhed;
    uint8_t  len;
    uint8_t  sum;

    // =========================================================
    //
    enum    {                       //  get byte state code.
        SYNCGET,
        SIZEGET,
        DATAGET
    }   st= SYNCGET; //

    pkhed = (PKBASEHED*)buf;
//    pkhed = (PKBASEHED*)&info->line[0];
    while(1) {
        ret = uif_getbyte(&getb);   //  Get byte from UART
        if(ret!= 1) {             //  Check TIME UP
//          st= SYNCGET;            //  to Serch SYNC CODE Mode.
            continue;
        }
        buff[len]=getb;

        len ++;
        sum +=  getb;               //  Clear Sumcounter.
        switch(st) {
        case SYNCGET:
            // =========================================================
            //  同期コード
            if(UIF_SYNCCODE == getb) {
//                uif_flashrp(info);      //  同期コードまでは破棄
                st  = SIZEGET;
                len = 0;
                sum = 0;
            }else {                     //  バッファサイズをケア20130926
                if(len > UIF_BUFUSELEN/2) {   //  バッファが増えてきた
//                    uif_flashrp(info);  //  ここまでは不要なので破棄する。
                    len = 0;            //  同期取るまではバッファカウンタとして機能。
                }
            }
            break;
        case SIZEGET:
            // =========================================================
            //  Get Size
            pkhed->pklen = getb ;
            if  ((pkhed->pklen <  sizeof(PKBASEHED))  //  小さすぎるとき
             ||  (pkhed->pklen >= UIF_BUFUSELEN))     //  大きすぎるとき
                st = SYNCGET;           //  再度同期探索
            else
                st = DATAGET;
            break;
        case DATAGET:
            // =========================================================
            // Get All Data
            if(pkhed->pklen <= len)    {
                //  check packet length.
               if((sum) == 0){         //  Check SUM CODE
//               if(1){         //  Check SUM CODE
                    //  Success get command.
                    //  Copy commnad.
                    if (len < buflen)
                        buflen = len;
//                    memcpy(buf, pkhed,  buflen);
                    memcpy(buf, buff, buflen);
                    //  flash buffer
//                    uif_flashlen(info,  len);   //
                    st= SYNCGET;    //
                    return  pkhed;  //  SUCCESS get data.
                }else {
                    err_pktsum  ++;
                    //  Sum error reget next synccode.
//                    uif_rewind(info);
                    // for debug
//                    memcpy(buff, pkhed,  len);
                    st= SYNCGET;    //
                }
            }
            break;
        default:                //  Err this state.
//            uif_flashrp(info);  //  Flash buffer
            st= SYNCGET;    //
        }
    }
    return (PKBASEHED*)NULL;
}
#endif
// =========================================================
//
//  レジスタ通信　put
//
static receive_regput(msgAttachData_t *pMsgQue)
{
    REG_MEM *reg_mem;
    PKBASEHED *pkthed;
    REGLINK *reglink;

//    pkthed  =   (PKBASEHED*)pMsgQue->Msg.data;
    pkthed  =   (PKBASEHED*)pMsgQue;
    reglink =   (REGLINK*)(pkthed+1);

    if (reg_mem = tbl_search(reglink->regno)) {
        // =========================================================
        // レジスタ処理実行
        (*reg_mem->putfunc)(reg_mem, pkthed);

//        Semaphore_post(msgQueus_sem);
        return  SUCCESS;
    }
    //
    uif_sendnack(pkthed,pkthed->pktid,0,0);

//    Semaphore_post(msgQueus_sem);
    return  ERR;
}

// =========================================================
//
//  レジスタ通信　get
//
static receive_regget(msgAttachData_t *pMsgQue)
{
    REG_MEM *reg_mem;
    PKBASEHED *pkthed;
    REGLINK *reglink;

    pkthed  =   (PKBASEHED*)pMsgQue;
    reglink =   (REGLINK*)(pkthed+1);

    if (reg_mem = tbl_search(reglink->regno)) {
        // =========================================================
        // レジスタ処理実行
        (*reg_mem->getfunc)(reg_mem, pkthed);

//        Semaphore_post(msgQueus_sem);
        return SUCCESS;
    }
    //　error send to nack
    uif_sendnack(pkthed,pkthed->pktid,0,0);

//    Semaphore_post(msgQueus_sem);
    return ERR;
}

// =========================================================
//
//  receive Beacon Request
//
static  void receive_beacon(msgAttachData_t* pMsgQue)
{
    PKBASEHED *pkthed;

    pkthed = (PKBASEHED*)pMsgQue;
    snd_alloc_count++;

    memcpy(que_dp,(uint8_t* )pkthed ,sizeof(que_dp));
//    Semaphore_post(msgQueus_sem);
}

// =========================================================
//
//  receive short address
//
static  void receive_dlong(msgAttachData_t* pMsgQue)
{
    PKBASEHED *pkthed;

    pkthed = (PKBASEHED*)pMsgQue;
    snd_alloc_count++;

//    Queue_enqueue(msgQueue, pkthed);
//    Semaphore_post(msgQueus_sem);
}
// =========================================================
//
//  receive short address
//
static  void receive_dshort(msgAttachData_t* pMsgQue)
{
    PKBASEHED *pkthed;

    pkthed = (PKBASEHED*)&pMsgQue->data[0];
    snd_alloc_count++;

//    Queue_enqueue(msgQueue, pkthed);
//    Semaphore_post(msgQueus_sem);

#if 0
    PKBASEHED   *pkthed;
    pkthed  =   (PKBASEHED*)pMsgQue->Msg.data;
    sendBuf->command = CCSND_CMD_SEND_DATA;//NET_CMD_SEND_SUCCESS;確認を行う
    sendBuf->result =   0;                              //
    sendBuf->id =   pkthed->pktid;
//    sendBuf->param  =   GetParamPtr(info);            //??
//    sendBuf->param  =   info->l2u_info;           //
    sendBuf->length =   (uint8_t)pkthed->pklen;     //
#endif
    //
#if 0    //  Comnnand　to L1
    writeCcSndMsgQue( CCSND_CMD_SEND_DATA, (void *)sendBuf );
#endif
}

// =========================================================
//
//  Uart Task sub function
//  function : void uart_u2l_taskmain()
//
void uart_u2l_taskmain()
{
    static PKBASEHED *pkthed = NULL;
    static msgAttachData_t *attach = NULL;
    int ret = 1;

//    Container_Handle U2lHandle = 0;           // message buffer (Container)
//    ContainerObj_t MsgQue = NULL;
//    Queue_Handle queHandle = NULL ;

    // ==========================================================
    //  Create Container
    U2lTask_init(NULL);

    // ==========================================================
    // get message que
#ifndef ___TM
    U2lHandle = getU2lTaskContainerInfo();
    if(!U2lHandle)
        return 0;
    queHandle = Container_GetQueueHandle(U2lHandle);
    if(!queHandle)
        return 0;
#endif

    while(ret)
    {
        if(attach == NULL)
        {
#if 0
            cp = uifGetBuf( info->uif_info );
            attach = (msgAttachData_t *)COMBUF_CARRYP(cp);
            pkthed = (PKBASEHED*)&attach->data;
#else
            // ==========================================================
            //
#ifdef ___TM
            attach = Memory_alloc(NULL, (int)sizeof(msgAttachData_t), 0, &g_eb);
//            MsgQue = malloc ((int) sizeof(msgAttachData_t));
            pkthed = (PKBASEHED*)attach;
#else
            MsgQue = Container_alloc(U2lHandle);
            if(!MsgQue)
                return 0;
            pkthed = (PKBASEHED*)&MsgQue->Msg.data;
#endif
#endif
        }
        if(pkthed == NULL)
            continue;
        // ==========================================================
        //　UART Packet　受信
        pkthed = uif_getpkt((uint8_t*)pkthed, uifGetBufLen());
        if(pkthed == NULL)
        {
            // =========================================================
            //  データが無いので、再読取り。
            continue;
        }
        // =========================================================
        // Packet 受信
        switch (pkthed->comtype)
        {
        case PKCOM_ACK:
            // ======================================================
            // ACK 送信
#ifdef ___TM
            Memory_free(NULL, attach,  (int)sizeof(msgWisunAttachData_t));
#else
            Container_free(attach);
#endif
            attach = NULL;
            break;
        case PKCOM_NACK:
            // ======================================================
            // NACK 送信
#ifdef ___TM
            Memory_free(NULL, attach,  (int)sizeof(msgAttachData_t));
#else
            Container_free(attach);
#endif
            attach = NULL;
            break;
        case PKCOM_BEACON:
            // ======================================================
            // beacon
        {
//            uint8_t pkid = 0 ;
            receive_beacon((msgAttachData_t *)pkthed);
            ret = 0;
//            uif_sendack(pkthed, pkid);
        }
#ifdef ___TM
//            Memory_free(NULL, attach,  (int)sizeof(msgAttachData_t));
#else
            Container_free(attach);
#endif
//            attach = NULL;
            break;
        case PKCOM_DLONG:
            // ======================================================
            // Long address mode
//            receive_dlong(attach);

            // ======================================================
            // free queue
#ifdef ___TM
            Memory_free(NULL, attach,  (int)sizeof(msgAttachData_t));
#else
            Container_free(attach);
#endif
            attach = NULL;
            break;
        case PKCOM_DSHORT:
            // ======================================================
            //  伝送電文到着
            receive_dshort(attach);

            // ======================================================
            // free queue
#ifdef ___TM
            Memory_free(NULL, attach,  (int)sizeof(msgAttachData_t));
#else
            Container_free(attach);
#endif
            attach = NULL;
            ret = 0;
            break;
        case PKCOM_REGPUT:
            // ======================================================
            //  レジスタプット処理
            receive_regput(attach);

            // ======================================================
            // free queue
#ifdef ___TM
            Memory_free(NULL, attach,  (int)sizeof(msgAttachData_t));
#else
            Container_free(attach);
#endif
            attach = NULL;
            // =========================================================
            // 不具合　レジスタ通信はreturn しない
            // ret = 0;
            break;
        case PKCOM_REGGET:
            // ======================================================
            //  レジスタゲット処理
            receive_regget(attach);

            // ======================================================
            // free queue
#ifdef ___TM
            Memory_free(NULL, attach,  (int)sizeof(msgAttachData_t));
#else
            Container_free(attach);
#endif
            attach = NULL;
            // =========================================================
            // 不具合　レジスタ通信はreturn しない
            // ret = 0;
            break;
        default :
            //  NACK
            break;
        }
    }
}
// =========================================================
// - end of file
// =========================================================

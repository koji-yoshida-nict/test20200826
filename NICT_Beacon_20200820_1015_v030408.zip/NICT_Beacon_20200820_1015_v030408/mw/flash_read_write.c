//******************************************************************************
//	@file	flash_write_inf.c
//******************************************************************************

/**
 *	@brief	Single-Byte Flash write.
 *			Flash(Information memory segment) B~D segments
 *
 *	@author	T.Kaneko
 *	@date	2011-12-12
 *Input parameters
 *	@param	int				seg_no  - 1 ~ 3 (B ~ D, 128byte unit)
 *	@param	unsigned char	*start_adr  - data source start address
 *	@param	long			leng  - data source copy size
 *Output parameters
 *	@return	0:OK -1:NG(arg error)
 *
 *	exsample	flash_write_inf( 1, test_data, 128 );
 */
#include <stdint.h>
#include <driverlib/flash.h>
#include <ti/sysbios/knl/Task.h>
#include "flash_read_write.h"

int flash_write(int seg_no, unsigned char *start_adr, long leng)
{
    uint32_t flashAddr = seg_no * SECTOR_SIZE;
    uint32_t i;

    //割込み禁止処理開始
//    taskENTER_CRITICAL();
	
    FlashSectorErase(flashAddr);
//    FlashsafeProgram(start_adr, flashAddr, leng);
    i = FlashProgram(start_adr, flashAddr, leng);

    //割込み禁止処理終了
//    taskEXIT_CRITICAL();

    return 0;
}

/**
 *	@brief	Single-Byte Flash read.
 *			Flash(Information memory segment) B~D segments
 *
 *	@author	T.Kaneko
 *	@date	2011-12-12
 *Input parameters
 *	@param	int				seg_no  - 1 ~ 3 (B ~ D, 128byte unit)
 *	@param	unsigned char	*start_adr  - data source start address
 *	@param	long			leng  - data source copy size
 *Output parameters
 *	@return	0:OK -1:NG(arg. error)
 *
 *	exsample	flash_read_inf( 1, test_data, sizeof(test_data) );
 */
 int flash_read(int seg_no, unsigned char *start_adr, long leng)
{
    uint32_t flashAddr = seg_no * SECTOR_SIZE;

	//割込み禁止処理開始
//    taskENTER_CRITICAL();

#if 0
    memcpy(start_adr, &flashAddr, leng);
#endif
    memcpy(start_adr, flashAddr, leng);

    //割込み禁止処理終了
//    taskEXIT_CRITICAL();

    return 0;
}	
